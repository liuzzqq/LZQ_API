create definer = root@`%` view v_rules_firm as
select `a`.`rule_id`                                   AS `ruleId`,
       group_concat(distinct `c`.`name` separator ',') AS `firmName`,
       group_concat(distinct `c`.`code` separator ',') AS `firmCode`
from ((`swsc_woodpecker_test`.`se_push_rule_person` `a` left join `swsc_woodpecker_test`.`se_company_employee` `b` on ((`a`.`person_code` = `b`.`user_id`)))
         left join `swsc_woodpecker_test`.`se_company` `c` on ((`c`.`code` = `b`.`company_code`)))
group by `a`.`rule_id`;

