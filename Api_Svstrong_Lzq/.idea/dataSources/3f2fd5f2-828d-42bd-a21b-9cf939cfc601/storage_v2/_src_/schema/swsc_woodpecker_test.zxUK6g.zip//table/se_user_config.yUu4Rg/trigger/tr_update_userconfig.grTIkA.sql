create definer = root@`%` trigger tr_update_userconfig
    after update
    on se_user_config
    for each row
BEGIN
    UPDATE swsc_raccon_back.se_user_config
			SET account=new.user_id,openid=new.openid,type=new.type
     WHERE id = new.id;
END;

