create definer = root@`%` view v_wp_ordernumbynameanddate as
select `a`.`repair_id` AS `name`, count(0) AS `num`, substr(`a`.`create_time`, 1, 10) AS `createTime`
from `swsc_woodpecker_test`.`se_order` `a`
where (`a`.`order_time` is not null)
group by `a`.`repair_id`, substr(`a`.`create_time`, 1, 10);

