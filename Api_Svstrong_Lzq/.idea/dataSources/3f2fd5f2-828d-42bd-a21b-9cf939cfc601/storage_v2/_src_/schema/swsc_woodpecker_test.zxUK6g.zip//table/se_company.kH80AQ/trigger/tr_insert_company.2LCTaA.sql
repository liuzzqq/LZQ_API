create definer = root@`%` trigger tr_insert_company
    after insert
    on se_company
    for each row
BEGIN
    INSERT INTO
      swsc_raccon_back.se_company(id,code,name,address,status)
    VALUES
      (new.id,new.code, new.name,new.address,new.status);
END;

