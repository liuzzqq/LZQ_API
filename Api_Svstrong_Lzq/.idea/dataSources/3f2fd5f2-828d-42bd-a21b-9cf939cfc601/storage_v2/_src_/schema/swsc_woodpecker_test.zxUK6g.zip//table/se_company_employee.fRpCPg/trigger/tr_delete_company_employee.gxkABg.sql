create definer = root@`%` trigger tr_delete_company_employee
    after delete
    on se_company_employee
    for each row
BEGIN
  DELETE FROM swsc_raccon_back.se_company_employee WHERE id = old.id;
END;

