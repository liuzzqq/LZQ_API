create definer = root@`%` trigger tr_delete_company
    after delete
    on se_company
    for each row
BEGIN
  DELETE FROM swsc_raccon_back.se_company WHERE id = old.id;
END;

