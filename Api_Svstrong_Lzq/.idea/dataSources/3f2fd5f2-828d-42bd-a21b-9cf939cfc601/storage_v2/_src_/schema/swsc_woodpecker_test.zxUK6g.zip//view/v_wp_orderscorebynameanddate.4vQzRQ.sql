create definer = root@`%` view v_wp_orderscorebynameanddate as
select `swsc_woodpecker_test`.`se_order`.`repair_id`                                                                AS `name`,
       (case
            when (timestampdiff(HOUR, `swsc_woodpecker_test`.`se_order`.`order_time`,
                                `swsc_woodpecker_test`.`se_order`.`complete_time`) > 48) then '0	'
            when (timestampdiff(HOUR, `swsc_woodpecker_test`.`se_order`.`order_time`,
                                `swsc_woodpecker_test`.`se_order`.`complete_time`) between 24 and 48) then '60'
            when (timestampdiff(HOUR, `swsc_woodpecker_test`.`se_order`.`order_time`,
                                `swsc_woodpecker_test`.`se_order`.`complete_time`) between 4 and 24) then '80'
            when (timestampdiff(HOUR, `swsc_woodpecker_test`.`se_order`.`order_time`,
                                `swsc_woodpecker_test`.`se_order`.`complete_time`) between 0 and 4)
                then '100' end)                                                                                     AS `score`,
       substr(`swsc_woodpecker_test`.`se_order`.`create_time`, 1, 10)                                               AS `createTime`
from `swsc_woodpecker_test`.`se_order`
where ((`swsc_woodpecker_test`.`se_order`.`complete_time` is not null) and
       (`swsc_woodpecker_test`.`se_order`.`order_time` is not null))
group by `swsc_woodpecker_test`.`se_order`.`repair_id`, `swsc_woodpecker_test`.`se_order`.`create_time`;

