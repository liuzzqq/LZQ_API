create definer = root@`%` trigger tr_insert_user
    after insert
    on sys_user
    for each row
BEGIN
    INSERT INTO
      swsc_raccon_back.sys_user(account,password,salt,email,status,mobile,real_name,user_icon)
    VALUES
      (new.username, new.password,new.salt,new.email,new.status,new.phone,new.realname,new.avatar);
		insert into swsc_raccon_back.sys_user_role(user_id,role_id) 
  	 values(LAST_INSERT_ID(),'33');	
END;

