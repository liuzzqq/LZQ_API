create definer = root@`%` trigger tr_update_company_employee
    after update
    on se_company_employee
    for each row
BEGIN
    UPDATE swsc_raccon_back.se_company_employee
	SET company_code=if(new.company_code='678','030ae062061d4cd986a0aeb3ba633773',new.company_code)
     WHERE id = new.id;
END;

