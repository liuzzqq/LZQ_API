create definer = root@`%` trigger tr_delete_userconfig
    after delete
    on se_user_config
    for each row
BEGIN
  DELETE FROM swsc_raccon_back.se_user_config WHERE id = old.id;
END;

