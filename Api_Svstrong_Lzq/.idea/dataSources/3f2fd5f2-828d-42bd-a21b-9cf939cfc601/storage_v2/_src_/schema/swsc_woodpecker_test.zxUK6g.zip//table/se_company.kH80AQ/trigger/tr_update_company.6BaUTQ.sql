create definer = root@`%` trigger tr_update_company
    after update
    on se_company
    for each row
BEGIN
    UPDATE swsc_raccon_back.se_company
	SET name=new.name,address=new.address,status=new.status
     WHERE code = new.code;
END;

