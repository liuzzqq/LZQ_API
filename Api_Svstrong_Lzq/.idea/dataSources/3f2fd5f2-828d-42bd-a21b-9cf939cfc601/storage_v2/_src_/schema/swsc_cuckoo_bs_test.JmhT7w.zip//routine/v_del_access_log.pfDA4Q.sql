create
    definer = root@`%` procedure v_del_access_log()
BEGIN
	#Routine body goes here...
	DELETE FROM bs_access_log where access_time < DATE_SUB(CURDATE(),INTERVAL 7 DAY);
END;

