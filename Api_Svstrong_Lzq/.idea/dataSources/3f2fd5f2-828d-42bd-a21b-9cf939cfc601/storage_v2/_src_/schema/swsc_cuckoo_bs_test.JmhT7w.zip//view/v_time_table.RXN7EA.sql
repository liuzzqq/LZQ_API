create definer = root@`%` view v_time_table as
select `a`.`guid`                                     AS `guid`,
       `a`.`course_id`                                AS `course_id`,
       `a`.`week_day`                                 AS `week_day`,
       `a`.`section_no`                               AS `section_no`,
       `a`.`class_room_id`                            AS `class_room_id`,
       group_concat(`b`.`teacher_name` separator ',') AS `teacher_name`
from (`swsc_cuckoo_bs_test`.`bs_time_table` `a`
         left join `swsc_cuckoo_bs_test`.`bs_course_teacher` `b`
                   on (((`a`.`guid` = `b`.`course_id`) and (`b`.`is_delete` = 0))))
where (`a`.`is_delete` = 0)
group by `b`.`teacher_name`, `a`.`course_id`, `a`.`week_day`, `a`.`section_no`, `a`.`class_room_id`;

