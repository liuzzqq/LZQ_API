create
    definer = root@`%` procedure proc_grade_scale_analysis(IN sortNum int(5), IN exam_id varchar(32))
BEGIN
-- 定义所需参数
	DECLARE i INT(5) DEFAULT 0;
	DECLARE done INT(5) DEFAULT 0;
	DECLARE scale_name VARCHAR(32) DEFAULT 'scale_name_';
	DECLARE class_scale_num VARCHAR(32) DEFAULT 'class_scale_num_';
	DECLARE district_num VARCHAR(32) DEFAULT 'district_num_';
	DECLARE sort_name VARCHAR(32) DEFAULT 'sort_';
	DECLARE name_suf INT(5);
	DECLARE count INT(5) DEFAULT 0;
-- 	新增列的sql
	DECLARE scale_name_sql VARCHAR(500) DEFAULT '';
	DECLARE class_scale_num_sql VARCHAR(500) DEFAULT '';
	DECLARE district_num_sql VARCHAR(500) DEFAULT '';
	DECLARE sort_name_sql VARCHAR(500) DEFAULT '';
	 -- 第一次查询所需的
	DECLARE guid1 varchar(200); 
	DECLARE examName varchar(200); 
	DECLARE examType varchar(200); 
	DECLARE levelYear varchar(200); 
	DECLARE className varchar(200); 
	DECLARE lastNum VARCHAR(200) DEFAULT '';
	DECLARE realNum VARCHAR(200) DEFAULT '';
	-- 第二次查询所需的
	DECLARE guid2 varchar(200); 
	DECLARE sort VARCHAR(200) DEFAULT '';
	DECLARE scaleName VARCHAR(200) DEFAULT '';
	DECLARE districtNum VARCHAR(200) DEFAULT '';
	DECLARE classScaleNum VARCHAR(200) DEFAULT '';
	
-- 	insert_sql
	DECLARE insert_sql VARCHAR(21845) DEFAULT '';
	DECLARE insert_sql_pre VARCHAR(21845) DEFAULT '';
	DECLARE insert_sql_suf VARCHAR(21845) DEFAULT '';
	DECLARE insert_sql_sep VARCHAR(21845) DEFAULT '';
	DECLARE insert_sql_value VARCHAR(21845) DEFAULT '';

-- 定义guid游标用于循环
 DECLARE guidCursor CURSOR FOR select guid as guid1,exam_name as examName,exam_type as examType,level_year as levelYear,class_name as className,real_num as realNum from an_grade_scale_analysis where exam_guid = exam_id; 
-- 定义info游标用于循环
--  DECLARE infoCursor CURSOR FOR select t2.guid as guid2,t1.sort,t1.scale_name as scaleName,t1.district_num as districtNum,class_scale_num as classScaleNum from an_scale t1 left join an_grade_scale_analysis t2 on t1.grade_scale_guid = t2.guid where t1.exam_guid = exam_id and t2.guid = guid1; 
 DECLARE infoCursor CURSOR FOR select t1.grade_scale_guid as guid2,t1.sort,t1.scale_name as scaleName,t1.district_num as districtNum,class_scale_num as classScaleNum from an_scale t1 where t1.exam_guid = exam_id and t1.grade_scale_guid = guid1;
	 
 DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;
	 
-- 查询出行表最大段数
	set count = 0;
	IF sortNum > count
		THEN 
			SET @newCols = sortNum - count;
-- 			WHILE i<@newCols DO
-- 					SET scale_name = 'scale_name_';
-- 					SET class_scale_num = 'class_scale_num_';
-- 					SET district_num = 'district_num_';
-- 					SET sort_name = 'sort_';
-- 					SET name_suf = count+i+1;
-- -- 			执行新建列(scale_name、class_scale_num、district_num、sort)
-- 					SET scale_name = CONCAT(scale_name,name_suf);
-- 					SET class_scale_num = CONCAT(class_scale_num,name_suf);
-- 					SET district_num = CONCAT(district_num,name_suf);
-- 					SET sort_name = CONCAT(sort_name,name_suf);
-- 					SET scale_name_sql = CONCAT('alter table an_scale_analysis_rows add column ',scale_name,' varchar(32)');
-- 					SET class_scale_num_sql = CONCAT('alter table an_scale_analysis_rows add column ',class_scale_num,' int(11)');
-- 					SET district_num_sql = CONCAT('alter table an_scale_analysis_rows add column ',district_num,' int(11)');
-- 					SET sort_name_sql = CONCAT('alter table an_scale_analysis_rows add column ',sort_name,' int(11)');
-- -- 					SELECT scale_name_sql; 
-- -- 					SELECT class_scale_num_sql; 
-- -- 					SELECT district_num_sql; 
-- -- 					SELECT sort_name_sql; 
-- 					SET @scale_name_sql=scale_name_sql;
-- 					SET @class_scale_num_sql=class_scale_num_sql;
-- 					SET @district_num_sql=district_num_sql;
-- 					SET @sort_name_sql=sort_name_sql;
-- 					PREPARE stmt0 FROM @scale_name_sql;
-- 					PREPARE stmt1 FROM @class_scale_num_sql;
-- 					PREPARE stmt2 FROM @district_num_sql;
-- 					PREPARE stmt3 FROM @sort_name_sql;
-- 					EXECUTE stmt0;
-- 					EXECUTE stmt1;
-- 					EXECUTE stmt2;
-- 					EXECUTE stmt3;
-- 					DEALLOCATE PREPARE stmt0;
-- 					DEALLOCATE PREPARE stmt1;
-- 					DEALLOCATE PREPARE stmt2;
-- 					DEALLOCATE PREPARE stmt3;
-- 
-- 				SET i = i + 1 ;
-- 			END WHILE;
	END IF;
-- 	同步数据至行表	
-- 1查询	
-- a-查询出本次考试的所有guid

-- 打开guid游标
		OPEN guidCursor;
	
-- 	b-根据guid查询本次的所有排序过后的分数段进行插入
	 myLoop: LOOP   
			FETCH guidCursor into guid1,examName,examType,levelYear,className,realNum;
			IF done = 1 THEN -- 判断是否继续循环  
				LEAVE myLoop; -- 结束循环  
			END IF;  
					-- 查询所需要插入的数据  
					-- 打开info游标
					OPEN infoCursor;
					myLoop2: LOOP   
					FETCH infoCursor into guid2,sort,scaleName,districtNum,classScaleNum;
					IF done = 1 THEN -- 判断是否继续循环  
						LEAVE myLoop2; -- 结束循环  
					END IF; 
					-- 处理inser_sql字段值
					SET insert_sql_pre = CONCAT(insert_sql_pre,',',scale_name,sort,',',class_scale_num,sort,',',district_num,sort,',',sort_name,sort);
					SET insert_sql_suf = CONCAT(insert_sql_suf,',',scaleName,',',classScaleNum,',',districtNum,',',sort);
					SELECT insert_sql_suf;
					FETCH infoCursor into guid2,sort,scaleName,districtNum,classScaleNum;
					END LOOP myLoop2; -- 结束自定义循环体  
					CLOSE infoCursor; -- 关闭游标  
					
-- 					处理insert_sql values
					SET insert_sql = CONCAT('INSERT INTO an_scale_analysis_rows (','enter_year',',','exam_type',',','exam_name',',','class_name',insert_sql_pre,') VALUES (',levelYear,examType,examName,className,insert_sql_suf,')');
			
					SELECT insert_sql_suf;
-- 					PREPARE stmt5 FROM @insert_sql;
-- 					EXECUTE stmt5;
-- 					DEALLOCATE PREPARE stmt5;
				FETCH guidCursor into guid1,examName,examType,levelYear,className,realNum;
		END LOOP myLoop; -- 结束自定义循环体  
		CLOSE guidCursor; -- 关闭guid游标  


END;

