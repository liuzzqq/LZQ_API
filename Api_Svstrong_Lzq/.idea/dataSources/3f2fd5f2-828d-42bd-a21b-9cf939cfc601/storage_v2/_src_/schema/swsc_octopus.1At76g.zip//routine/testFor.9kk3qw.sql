create
    definer = root@`%` procedure testFor()
BEGIN
	 declare guid varchar(32); -- 自定义变量1  
   DECLARE guidCursor CURSOR FOR select t2.guid from  an_scale t1 left join an_grade_scale_analysis t2 on t1.grade_scale_guid = t2.guid where t1.exam_guid = '59623748750440c599a4320cace92788' group by t2.guid; 
-- 打开游标
		OPEN guidCursor;
-- 第二层查询
  myLoop: LOOP -- 开始循环体,myLoop为自定义循环名,结束循环时用到  
		FETCH guidCursor into guid;
		IF guid is null THEN -- 判断是否继续循环  
      LEAVE myLoop; -- 结束循环  
    END IF;  
    -- 自己要做的事情,在 sql 中直接使用自定义变量即可  
		select t2.level_year,t2.class_name,t2.exam_type,t2.exam_name,t2.last_num,t2.real_num,t1.sort,t1.scale_name,t1.class_scale_num,t1.district_num from  an_scale t1 left join an_grade_scale_analysis t2 on t1.grade_scale_guid = t2.guid
 where t1.exam_guid = '59623748750440c599a4320cace92788' and t2.guid = guid;
  
    COMMIT; -- 提交事务  
  END LOOP myLoop; -- 结束自定义循环体  
  CLOSE guidCursor; -- 关闭游标  
	
END;

