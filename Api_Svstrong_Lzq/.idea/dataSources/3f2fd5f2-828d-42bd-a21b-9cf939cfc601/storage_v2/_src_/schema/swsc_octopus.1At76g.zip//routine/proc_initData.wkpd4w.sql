create
    definer = root@`%` procedure proc_initData()
BEGIN  
    DECLARE i INT DEFAULT 1;  
    WHILE i<=7 DO  
        INSERT 

    INTO edu_student_class(class_guid,is_delete) VALUES('40282b816df793dd016df79427dc0001',0);
        SET i = i+1;  
    END WHILE;  
END;

