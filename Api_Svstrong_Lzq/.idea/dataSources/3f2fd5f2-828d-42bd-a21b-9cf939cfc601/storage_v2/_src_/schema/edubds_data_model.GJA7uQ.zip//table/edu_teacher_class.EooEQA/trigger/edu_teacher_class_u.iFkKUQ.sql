create definer = root@`%` trigger edu_teacher_class_u
    after update
    on edu_teacher_class
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_teacher_class', sysdate(), 'u', new.guid);
	end;

