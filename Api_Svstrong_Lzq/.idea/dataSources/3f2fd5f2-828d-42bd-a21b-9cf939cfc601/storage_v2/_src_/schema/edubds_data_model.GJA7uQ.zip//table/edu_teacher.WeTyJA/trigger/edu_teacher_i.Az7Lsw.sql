create definer = root@`%` trigger edu_teacher_i
    after insert
    on edu_teacher
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_teacher', sysdate(), 'i', new.guid);
	end;

