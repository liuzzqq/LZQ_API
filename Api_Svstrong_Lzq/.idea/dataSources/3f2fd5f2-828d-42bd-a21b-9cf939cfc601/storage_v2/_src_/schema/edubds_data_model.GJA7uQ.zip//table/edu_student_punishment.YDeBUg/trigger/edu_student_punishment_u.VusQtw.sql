create definer = root@`%` trigger edu_student_punishment_u
    after update
    on edu_student_punishment
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_punishment', sysdate(), 'u', new.guid);
	end;

