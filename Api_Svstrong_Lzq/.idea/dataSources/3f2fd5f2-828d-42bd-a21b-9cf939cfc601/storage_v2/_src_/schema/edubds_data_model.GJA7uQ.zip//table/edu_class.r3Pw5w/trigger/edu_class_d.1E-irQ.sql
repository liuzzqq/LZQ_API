create definer = root@`%` trigger edu_class_d
    after delete
    on edu_class
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_class', sysdate(), 'd', old.guid);
	end;

