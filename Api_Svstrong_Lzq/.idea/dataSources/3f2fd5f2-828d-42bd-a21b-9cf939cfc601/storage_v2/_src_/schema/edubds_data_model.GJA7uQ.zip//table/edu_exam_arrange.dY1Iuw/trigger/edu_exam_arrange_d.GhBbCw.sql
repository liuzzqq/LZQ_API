create definer = root@`%` trigger edu_exam_arrange_d
    after delete
    on edu_exam_arrange
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_exam_arrange', sysdate(), 'd', old.guid);
	end;

