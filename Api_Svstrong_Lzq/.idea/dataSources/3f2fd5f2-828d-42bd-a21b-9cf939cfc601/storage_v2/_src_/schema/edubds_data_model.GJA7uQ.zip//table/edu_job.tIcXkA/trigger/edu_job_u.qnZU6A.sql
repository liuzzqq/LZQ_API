create definer = root@`%` trigger edu_job_u
    after update
    on edu_job
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_job', sysdate(), 'u', new.guid);
	end;

