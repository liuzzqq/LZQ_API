create definer = root@`%` trigger edu_grade_i
    after insert
    on edu_grade
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_grade', sysdate(), 'i', new.guid);
	end;

