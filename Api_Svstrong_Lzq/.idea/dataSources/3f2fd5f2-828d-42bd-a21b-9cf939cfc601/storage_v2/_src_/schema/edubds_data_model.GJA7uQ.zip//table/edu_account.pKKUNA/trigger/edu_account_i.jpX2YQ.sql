create definer = root@`%` trigger edu_account_i
    after insert
    on edu_account
    for each row
begin   

	   insert into cif_oplog(tablename, opdatetime, optype, guid) values ('edu_account', sysdate(), 'i', new.guid);

end;

