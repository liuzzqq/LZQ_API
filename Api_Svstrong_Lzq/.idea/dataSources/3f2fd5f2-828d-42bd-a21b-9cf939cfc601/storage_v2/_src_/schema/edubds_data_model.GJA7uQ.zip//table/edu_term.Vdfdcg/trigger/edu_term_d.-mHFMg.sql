create definer = root@`%` trigger edu_term_d
    after delete
    on edu_term
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_term', sysdate(), 'd', old.guid);
	end;

