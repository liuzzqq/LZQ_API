create definer = root@`%` trigger edu_term_i
    after insert
    on edu_term
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_term', sysdate(), 'i', new.guid);
	end;

