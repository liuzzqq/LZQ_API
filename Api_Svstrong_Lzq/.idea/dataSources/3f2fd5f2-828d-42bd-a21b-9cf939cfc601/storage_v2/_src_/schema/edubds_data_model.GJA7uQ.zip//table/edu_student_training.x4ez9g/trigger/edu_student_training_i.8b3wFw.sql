create definer = root@`%` trigger edu_student_training_i
    after insert
    on edu_student_training
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_training', sysdate(), 'i', new.guid);
	end;

