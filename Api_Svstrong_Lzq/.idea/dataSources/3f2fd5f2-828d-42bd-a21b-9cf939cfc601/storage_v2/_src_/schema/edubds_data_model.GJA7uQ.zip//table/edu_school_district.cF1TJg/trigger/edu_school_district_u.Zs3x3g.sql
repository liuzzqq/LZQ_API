create definer = root@`%` trigger edu_school_district_u
    after update
    on edu_school_district
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_school_district', sysdate(), 'u', new.guid);
	end;

