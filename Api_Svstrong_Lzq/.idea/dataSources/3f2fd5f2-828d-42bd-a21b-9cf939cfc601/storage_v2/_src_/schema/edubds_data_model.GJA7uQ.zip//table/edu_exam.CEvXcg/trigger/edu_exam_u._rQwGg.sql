create definer = root@`%` trigger edu_exam_u
    after update
    on edu_exam
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_exam', sysdate(), 'u', new.guid);
	end;

