create definer = root@`%` trigger edu_grade_u
    after update
    on edu_grade
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_grade', sysdate(), 'u', new.guid);
	end;

