create definer = root@`%` trigger edu_teacher_education_i
    after insert
    on edu_teacher_education
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_teacher_education', sysdate(), 'i', new.guid);
	end;

