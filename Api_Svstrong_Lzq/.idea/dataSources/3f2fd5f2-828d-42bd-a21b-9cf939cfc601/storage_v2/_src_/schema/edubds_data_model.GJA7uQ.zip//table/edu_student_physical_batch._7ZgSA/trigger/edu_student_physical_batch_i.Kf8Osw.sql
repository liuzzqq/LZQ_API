create definer = root@`%` trigger edu_student_physical_batch_i
    after insert
    on edu_student_physical_batch
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_physical_batch', sysdate(), 'i', new.guid);
	end;

