create definer = root@`%` trigger edu_student_reward_u
    after update
    on edu_student_reward
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_reward', sysdate(), 'u', new.guid);
	end;

