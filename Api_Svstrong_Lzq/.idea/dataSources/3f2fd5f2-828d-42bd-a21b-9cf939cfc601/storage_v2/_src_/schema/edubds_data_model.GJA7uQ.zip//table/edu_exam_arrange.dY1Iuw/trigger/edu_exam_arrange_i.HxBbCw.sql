create definer = root@`%` trigger edu_exam_arrange_i
    after insert
    on edu_exam_arrange
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_exam_arrange', sysdate(), 'i', new.guid);
	end;

