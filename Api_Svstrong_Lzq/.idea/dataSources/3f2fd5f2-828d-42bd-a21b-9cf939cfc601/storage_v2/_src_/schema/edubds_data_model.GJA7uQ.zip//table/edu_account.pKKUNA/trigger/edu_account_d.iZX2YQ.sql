create definer = root@`%` trigger edu_account_d
    after delete
    on edu_account
    for each row
begin   



	   insert into cif_oplog(tablename, opdatetime, optype, guid) values ('edu_account', sysdate(), 'd', old.guid);

end;

