create definer = root@`%` trigger edu_teacher_subject_d
    after delete
    on edu_teacher_subject
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_teacher_subject', sysdate(), 'd', old.guid);
	end;

