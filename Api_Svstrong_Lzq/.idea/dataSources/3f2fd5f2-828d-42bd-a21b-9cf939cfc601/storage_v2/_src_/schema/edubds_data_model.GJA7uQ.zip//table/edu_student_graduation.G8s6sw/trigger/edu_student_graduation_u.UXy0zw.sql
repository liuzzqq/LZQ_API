create definer = root@`%` trigger edu_student_graduation_u
    after update
    on edu_student_graduation
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_graduation', sysdate(), 'u', new.guid);
	end;

