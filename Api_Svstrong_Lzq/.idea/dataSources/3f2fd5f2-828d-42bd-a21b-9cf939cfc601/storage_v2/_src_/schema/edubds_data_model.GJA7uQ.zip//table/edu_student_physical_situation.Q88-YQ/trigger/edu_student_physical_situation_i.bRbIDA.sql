create definer = root@`%` trigger edu_student_physical_situation_i
    after insert
    on edu_student_physical_situation
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_physical_situation', sysdate(), 'i', new.guid);
	end;

