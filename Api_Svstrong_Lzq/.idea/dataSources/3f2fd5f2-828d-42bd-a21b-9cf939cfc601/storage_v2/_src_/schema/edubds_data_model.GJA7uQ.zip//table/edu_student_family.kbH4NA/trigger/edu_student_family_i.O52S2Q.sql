create definer = root@`%` trigger edu_student_family_i
    after insert
    on edu_student_family
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_family', sysdate(), 'i', new.guid);
	end;

