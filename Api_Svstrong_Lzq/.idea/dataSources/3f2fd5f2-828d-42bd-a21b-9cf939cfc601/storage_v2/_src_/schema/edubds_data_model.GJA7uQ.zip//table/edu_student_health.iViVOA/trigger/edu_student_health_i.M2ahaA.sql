create definer = root@`%` trigger edu_student_health_i
    after insert
    on edu_student_health
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_health', sysdate(), 'i', new.guid);
	end;

