create definer = root@`%` trigger edu_year_i
    after insert
    on edu_year
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_year', sysdate(), 'i', new.guid);
	end;

