create definer = root@`%` trigger edu_student_political_i
    after insert
    on edu_student_political
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_political', sysdate(), 'i', new.guid);
	end;

