create definer = root@`%` trigger edu_class_i
    after insert
    on edu_class
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_class', sysdate(), 'i', new.guid);
	end;

