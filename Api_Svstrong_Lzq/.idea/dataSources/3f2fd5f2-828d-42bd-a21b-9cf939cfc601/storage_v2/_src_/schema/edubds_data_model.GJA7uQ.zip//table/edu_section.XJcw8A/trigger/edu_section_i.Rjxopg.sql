create definer = root@`%` trigger edu_section_i
    after insert
    on edu_section
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_section', sysdate(), 'i', new.guid);
	end;

