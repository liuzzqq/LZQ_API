create definer = root@`%` trigger edu_department_u
    after update
    on edu_department
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_department', sysdate(), 'u', new.guid);
	end;

