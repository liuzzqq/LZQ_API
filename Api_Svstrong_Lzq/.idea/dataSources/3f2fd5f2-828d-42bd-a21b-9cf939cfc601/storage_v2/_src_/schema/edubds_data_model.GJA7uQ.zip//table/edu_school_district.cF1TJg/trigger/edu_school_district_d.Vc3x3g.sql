create definer = root@`%` trigger edu_school_district_d
    after delete
    on edu_school_district
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_school_district', sysdate(), 'd', old.guid);
	end;

