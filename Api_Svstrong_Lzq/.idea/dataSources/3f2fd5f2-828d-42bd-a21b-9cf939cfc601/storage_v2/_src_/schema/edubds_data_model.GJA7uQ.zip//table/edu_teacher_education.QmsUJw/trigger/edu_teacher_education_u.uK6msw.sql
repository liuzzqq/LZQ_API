create definer = root@`%` trigger edu_teacher_education_u
    after update
    on edu_teacher_education
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_teacher_education', sysdate(), 'u', new.guid);
	end;

