create definer = root@`%` trigger edu_section_u
    after update
    on edu_section
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_section', sysdate(), 'u', new.guid);
	end;

