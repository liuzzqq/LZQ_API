create definer = root@`%` trigger edu_teacher_d
    after delete
    on edu_teacher
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_teacher', sysdate(), 'd', old.guid);
	end;

