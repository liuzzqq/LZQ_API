create definer = root@`%` trigger edu_school_u
    after update
    on edu_school
    for each row
begin
	   IF (new.is_delete = 1) THEN
			insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_school', sysdate(), 'd', new.guid);
			else
			insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_school', sysdate(), 'u', new.guid);
	   END IF;
	end;

