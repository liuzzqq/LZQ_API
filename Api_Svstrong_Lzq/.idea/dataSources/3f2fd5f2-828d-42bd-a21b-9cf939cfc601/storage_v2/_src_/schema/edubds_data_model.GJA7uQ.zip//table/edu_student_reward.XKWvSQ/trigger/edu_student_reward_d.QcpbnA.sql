create definer = root@`%` trigger edu_student_reward_d
    after delete
    on edu_student_reward
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_reward', sysdate(), 'd', old.guid);
	end;

