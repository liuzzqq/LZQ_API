create definer = root@`%` trigger edu_student_physical_batch_d
    after delete
    on edu_student_physical_batch
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_physical_batch', sysdate(), 'd', old.guid);
	end;

