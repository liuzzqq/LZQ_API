create definer = root@`%` trigger edu_student_training_d
    after delete
    on edu_student_training
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student_training', sysdate(), 'd', old.guid);
	end;

