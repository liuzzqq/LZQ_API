create definer = root@`%` trigger edu_student_d
    after delete
    on edu_student
    for each row
begin

	insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_student', sysdate(), 'd', old.guid);

end;

