create definer = root@`%` trigger edu_subject_begins_i
    after insert
    on edu_subject_begins
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_subject_begins', sysdate(), 'i', new.guid);
	end;

