create definer = root@`%` trigger edu_section_d
    after delete
    on edu_section
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_section', sysdate(), 'd', old.guid);
	end;

