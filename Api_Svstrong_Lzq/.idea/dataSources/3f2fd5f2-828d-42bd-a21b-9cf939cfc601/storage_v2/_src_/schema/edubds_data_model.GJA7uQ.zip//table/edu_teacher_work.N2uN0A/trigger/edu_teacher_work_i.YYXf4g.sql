create definer = root@`%` trigger edu_teacher_work_i
    after insert
    on edu_teacher_work
    for each row
begin   
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_teacher_work', sysdate(), 'i', new.guid);
	end;

