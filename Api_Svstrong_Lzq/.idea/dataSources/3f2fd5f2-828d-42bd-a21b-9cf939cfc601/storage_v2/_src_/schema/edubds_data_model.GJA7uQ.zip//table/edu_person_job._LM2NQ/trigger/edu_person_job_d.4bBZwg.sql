create definer = root@`%` trigger edu_person_job_d
    after delete
    on edu_person_job
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_person_job', sysdate(), 'd', old.guid);
	end;

