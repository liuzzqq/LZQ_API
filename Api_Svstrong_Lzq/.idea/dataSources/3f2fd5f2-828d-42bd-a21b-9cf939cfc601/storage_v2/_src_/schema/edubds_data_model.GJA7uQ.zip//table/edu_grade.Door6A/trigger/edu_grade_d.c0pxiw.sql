create definer = root@`%` trigger edu_grade_d
    after delete
    on edu_grade
    for each row
begin
	   insert into cif_oplog (tablename, opdatetime, optype, guid) values ('edu_grade', sysdate(), 'd', old.guid);
	end;

