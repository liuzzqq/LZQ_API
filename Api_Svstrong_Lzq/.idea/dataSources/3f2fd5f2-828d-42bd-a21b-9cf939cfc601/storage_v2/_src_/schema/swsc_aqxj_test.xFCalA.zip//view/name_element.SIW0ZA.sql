create definer = root@`%` view name_element as
select `ssss`.`id`                                                                                     AS `id`,
       `ssss`.`parent_id`                                                                              AS `parent_id`,
       concat_ws('-', `f`.`element`, `s`.`element`, `ss`.`element`, `sss`.`element`, `ssss`.`element`) AS `names`,
       concat_ws('-', `f`.`element`, `s`.`element`, `ss`.`element`, `sss`.`element`)                   AS `names1`,
       `ssss`.`element`                                                                                AS `ssssname`,
       `sss`.`element`                                                                                 AS `sssname`,
       `sss`.`id`                                                                                      AS `sssid`,
       `ss`.`id`                                                                                       AS `ssid`,
       `s`.`id`                                                                                        AS `sid`,
       `f`.`id`                                                                                        AS `fid`,
       `ss`.`element`                                                                                  AS `ssname`,
       `s`.`element`                                                                                   AS `sname`,
       `f`.`element`                                                                                   AS `name`,
       `sss`.`sort`                                                                                    AS `sort`
from ((((`swsc_aqxj_test`.`hy_element` `ssss` left join `swsc_aqxj_test`.`hy_element` `sss` on ((`ssss`.`parent_id` = `sss`.`id`))) left join `swsc_aqxj_test`.`hy_element` `ss` on ((`sss`.`parent_id` = `ss`.`id`))) left join `swsc_aqxj_test`.`hy_element` `s` on ((`ss`.`parent_id` = `s`.`id`)))
         left join `swsc_aqxj_test`.`hy_element` `f` on ((`s`.`parent_id` = `f`.`id`)))
order by `ss`.`sort`, `ssss`.`parent_id`, `ssss`.`sort`;

