create definer = root@`%` view form_content as
select `a`.`id` AS `id`, `a`.`content_name` AS `content_name`
from `swsc_aqxj_test`.`hy_form_base` `a`
union all
select `a`.`id` AS `id`, `a`.`content_name` AS `content_name`
from `swsc_aqxj_test`.`hy_form_check` `a`;

