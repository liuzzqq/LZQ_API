create definer = root@`%` view v_assess_result as
select `result`.`id`                AS `id`,
       `result`.`assess_id`         AS `assess_id`,
       `result`.`title`             AS `title`,
       `result`.`identity`          AS `identity`,
       `result`.`evaluate_no`       AS `evaluate_no`,
       `result`.`evaluator_id`      AS `evaluator_id`,
       `result`.`advice`            AS `advice`,
       `result`.`assess_project_id` AS `assess_project_id`,
       `result`.`result`            AS `result`,
       `result`.`del_flag`          AS `del_flag`,
       `result`.`create_time`       AS `create_time`,
       `result`.`update_time`       AS `update_time`,
       `item`.`level1`              AS `level1`,
       `item`.`level2`              AS `level2`,
       `item`.`level3`              AS `level3`,
       `item`.`level4`              AS `level4`
from (`swsc_assess_dev`.`sz_assess_result` `result`
         left join (select `swsc_assess_dev`.`sz_assess_result_item`.`result_id`                               AS `result_id`,
                           count((case `swsc_assess_dev`.`sz_assess_result_item`.`level`
                                      when '1001'
                                          then `swsc_assess_dev`.`sz_assess_result_item`.`level` end))         AS `level1`,
                           count((case `swsc_assess_dev`.`sz_assess_result_item`.`level`
                                      when '1002'
                                          then `swsc_assess_dev`.`sz_assess_result_item`.`level` end))         AS `level2`,
                           count((case `swsc_assess_dev`.`sz_assess_result_item`.`level`
                                      when '1003'
                                          then `swsc_assess_dev`.`sz_assess_result_item`.`level` end))         AS `level3`,
                           count((case `swsc_assess_dev`.`sz_assess_result_item`.`level`
                                      when '1004'
                                          then `swsc_assess_dev`.`sz_assess_result_item`.`level` end))         AS `level4`
                    from `swsc_assess_dev`.`sz_assess_result_item`
                    group by `swsc_assess_dev`.`sz_assess_result_item`.`result_id`) `item`
                   on ((`result`.`id` = `item`.`result_id`)));

