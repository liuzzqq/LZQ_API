create definer = root@`%` view v_assess_rank as
select `mytable`.`assess_project_id` AS `assess_project_id`,
       `mytable`.`num`               AS `num`,
       sum(`mytable`.`zt_level1`)    AS `zt_level1`,
       sum(`mytable`.`zt_level2`)    AS `zt_level2`,
       sum(`mytable`.`zt_level3`)    AS `zt_level3`,
       sum(`mytable`.`zt_level4`)    AS `zt_level4`,
       sum(`mytable`.`level1`)       AS `level1`,
       sum(`mytable`.`level2`)       AS `level2`,
       sum(`mytable`.`level3`)       AS `level3`,
       sum(`mytable`.`level4`)       AS `level4`
from (select `a`.`assess_project_id`              AS `assess_project_id`,
             `c`.`num`                            AS `num`,
             sum(if((`a`.`result` = 1001), 1, 0)) AS `zt_level1`,
             sum(if((`a`.`result` = 1002), 1, 0)) AS `zt_level2`,
             sum(if((`a`.`result` = 1003), 1, 0)) AS `zt_level3`,
             sum(if((`a`.`result` = 1004), 1, 0)) AS `zt_level4`,
             0                                    AS `level1`,
             0                                    AS `level2`,
             0                                    AS `level3`,
             0                                    AS `level4`
      from ((`swsc_assess_dev`.`sz_assess_result` `a` left join `swsc_assess_dev`.`sz_assess_project` `b` on ((`a`.`assess_project_id` = `b`.`id`)))
               left join (select `t1`.`id` AS `id`, count(`t2`.`group_id`) AS `num`
                          from (`swsc_assess_dev`.`sz_assess_group` `t1`
                                   left join `swsc_assess_dev`.`sys_user` `t2`
                                             on (((`t1`.`id` = `t2`.`group_id`) and (`t2`.`super_admin` = '2'))))
                          where ((`t2`.`last_login_time` is not null) and (`t2`.`last_login_time` <> ''))
                          group by `t1`.`id`) `c` on ((`b`.`group_id` = `c`.`id`)))
      group by `a`.`assess_project_id`
      union all
      select `b`.`assess_project_id`             AS `assess_project_id`,
             0                                   AS `num`,
             0                                   AS `zt_level1`,
             0                                   AS `zt_level2`,
             0                                   AS `zt_level3`,
             0                                   AS `zt_level4`,
             sum(if((`a`.`level` = 1001), 1, 0)) AS `level1`,
             sum(if((`a`.`level` = 1002), 1, 0)) AS `level2`,
             sum(if((`a`.`level` = 1003), 1, 0)) AS `level3`,
             sum(if((`a`.`level` = 1004), 1, 0)) AS `level4`
      from (`swsc_assess_dev`.`sz_assess_result_item` `a`
               left join `swsc_assess_dev`.`sz_assess_result` `b` on ((`a`.`result_id` = `b`.`id`)))
      where (`b`.`assess_project_id` is not null)
      group by `b`.`assess_project_id`) `mytable`
group by `mytable`.`assess_project_id`;

