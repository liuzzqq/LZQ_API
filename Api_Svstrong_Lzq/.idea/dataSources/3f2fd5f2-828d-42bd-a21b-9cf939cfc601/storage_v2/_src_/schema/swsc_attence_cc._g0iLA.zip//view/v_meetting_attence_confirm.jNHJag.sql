create definer = root@`%` view v_meetting_attence_confirm as
select count(distinct `swsc_attence_cc`.`sw_meetting_user`.`user_id`) AS `number`,
       `swsc_attence_cc`.`sw_meetting_user`.`class_id`                AS `class_id`
from `swsc_attence_cc`.`sw_meetting_user`
where (`swsc_attence_cc`.`sw_meetting_user`.`is_confirm` = '1')
group by `swsc_attence_cc`.`sw_meetting_user`.`class_id`;

