create definer = root@`%` view v_attence as
select count(distinct `meetting_code`.`user_id`) AS `number`, `meetting_code`.`class_id` AS `class_id`
from `swsc_attence_cc`.`sw_attence_record` `meetting_code`
where (`meetting_code`.`absence` = '0')
group by `meetting_code`.`class_id`;

