create definer = root@`%` view v_outsiders_count as
select count(distinct `swsc_attence_cc`.`sw_meetting_user`.`user_id`) AS `number`,
       `swsc_attence_cc`.`sw_meetting_user`.`class_id`                AS `meettingCode`
from `swsc_attence_cc`.`sw_meetting_user`
where (`swsc_attence_cc`.`sw_meetting_user`.`type` = '3')
group by `swsc_attence_cc`.`sw_meetting_user`.`class_id`;

