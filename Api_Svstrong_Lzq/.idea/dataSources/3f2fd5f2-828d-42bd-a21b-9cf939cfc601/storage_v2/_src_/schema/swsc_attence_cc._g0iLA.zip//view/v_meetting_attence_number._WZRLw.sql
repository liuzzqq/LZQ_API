create definer = root@`%` view v_meetting_attence_number as
select count(distinct `swsc_attence_cc`.`sw_attence_record`.`user_id`) AS `number1`,
       `swsc_attence_cc`.`sw_attence_record`.`class_id`                AS `class_id`
from `swsc_attence_cc`.`sw_attence_record`
where (`swsc_attence_cc`.`sw_attence_record`.`absence` = '0')
group by `swsc_attence_cc`.`sw_attence_record`.`class_id`;

