create definer = root@`%` view v_user_trainning_attence_temp as
select count(`a`.`class_id`) AS `count`, `a`.`user_id` AS `user_id`
from (`swsc_attence_cc`.`sw_attence_record` `a`
         left join `swsc_attence_cc`.`sw_meetting` `b` on ((`a`.`class_id` = `b`.`code`)))
where ((`a`.`absence` = '0') and (`b`.`type` = '2'))
group by `a`.`user_id`;

