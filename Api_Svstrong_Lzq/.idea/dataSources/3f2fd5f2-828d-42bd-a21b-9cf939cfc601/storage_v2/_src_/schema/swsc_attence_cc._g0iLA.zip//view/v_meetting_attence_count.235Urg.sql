create definer = root@`%` view v_meetting_attence_count as
select count(distinct `swsc_attence_cc`.`sw_meetting_user`.`user_id`) AS `count`,
       `swsc_attence_cc`.`sw_meetting_user`.`class_id`                AS `class_id`
from `swsc_attence_cc`.`sw_meetting_user`
group by `swsc_attence_cc`.`sw_meetting_user`.`class_id`;

