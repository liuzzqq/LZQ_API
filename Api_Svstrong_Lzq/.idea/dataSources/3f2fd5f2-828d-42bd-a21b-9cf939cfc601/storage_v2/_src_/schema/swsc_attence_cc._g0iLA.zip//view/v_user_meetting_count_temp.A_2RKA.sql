create definer = root@`%` view v_user_meetting_count_temp as
select count(distinct `a`.`class_id`) AS `count`, `a`.`user_id` AS `user_id`
from (`swsc_attence_cc`.`sw_meetting_user` `a`
         left join `swsc_attence_cc`.`sw_meetting` `b` on ((`a`.`class_id` = `b`.`code`)))
where ((`a`.`is_confirm` = '1') and (`b`.`type` = '1'))
group by `a`.`user_id`;

