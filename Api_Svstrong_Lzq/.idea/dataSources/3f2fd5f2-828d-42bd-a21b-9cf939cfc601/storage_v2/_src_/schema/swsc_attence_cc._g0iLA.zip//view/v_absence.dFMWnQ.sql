create definer = root@`%` view v_absence as
select count(distinct `swsc_attence_cc`.`sw_attence_record`.`user_id`) AS `number`,
       `swsc_attence_cc`.`sw_attence_record`.`class_id`                AS `meettingCode`
from `swsc_attence_cc`.`sw_attence_record`
where (`swsc_attence_cc`.`sw_attence_record`.`absence` = '1')
group by `swsc_attence_cc`.`sw_attence_record`.`class_id`;

