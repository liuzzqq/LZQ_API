create definer = root@`%` view v_user_trainning_count as
select `a`.`user_id` AS `user_id`, (case when (`b`.`count` is not null) then `b`.`count` else 0 end) AS `number`
from (`swsc_attence_cc`.`sys_user` `a`
         left join `swsc_attence_cc`.`v_user_trainning_count_temp` `b` on ((`a`.`user_id` = `b`.`user_id`)));

