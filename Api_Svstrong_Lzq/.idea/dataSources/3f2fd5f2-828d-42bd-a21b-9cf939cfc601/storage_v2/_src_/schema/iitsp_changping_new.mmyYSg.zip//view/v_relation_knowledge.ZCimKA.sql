create definer = root@`%` view v_relation_knowledge as
select `r`.`master_login_id` AS `loginid`, count(0) AS `count_value`
from `iitsp_changping_new`.`relation_knowledge` `r`
where (`r`.`relation_type` = 'KnowledgeC')
group by `r`.`master_login_id`;

