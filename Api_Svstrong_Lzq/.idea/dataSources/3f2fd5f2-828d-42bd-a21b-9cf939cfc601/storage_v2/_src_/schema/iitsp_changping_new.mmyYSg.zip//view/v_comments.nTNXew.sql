create definer = root@`%` view v_comments as
select `f`.`create_by` AS `loginid`, count(0) AS `count_value`
from `iitsp_changping_new`.`comments` `f`
where (`f`.`commented_level` = '1')
group by `f`.`create_by`;

