create
    definer = root@`%` procedure reminding_the_number_of_spare()
BEGIN
  DECLARE done INT DEFAULT 0;
	DECLARE doneu INT DEFAULT 0;
  DECLARE i,w VARCHAR(64);
  DECLARE m LONGTEXT; 
  DECLARE cur1 CURSOR FOR SELECT AssetsCode FROM hardwareassets  h,notice n WHERE h.AssetsCode = n.NoticeId AND AssetsAmount > 0;
	DECLARE cur2 CURSOR FOR  SELECT a.AssetsCode,b.id FROM (SELECT n.AssetsCode FROM	hardwareassets n LEFT JOIN producttype p ON n.ProductType = p.RecId WHERE p.IsConsume='1' AND n.AssetsAmount = '0'   AND n.RealFlag='1') a LEFT JOIN (SELECT GROUP_CONCAT(s.LoginID) id  FROM siteviewsecmap s,userrole u,dictionary d WHERE s.LoginID=u.UserId AND s.GroupName = d.DictName AND u.RoleId ='库管' AND d.DictNo='unit') b ON 1=1; 
  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1,doneu = 1;

  OPEN cur1; 
  REPEAT
    FETCH cur1 INTO i; 
    IF NOT done THEN
       IF i IS NOT NULL THEN
         DELETE FROM notice WHERE NoticeId=i;
       END IF;
    END IF;
  UNTIL done END REPEAT;
  CLOSE cur1;
  
  SET doneu = 0; 
	OPEN cur2; 

  REPEAT
    FETCH cur2 INTO w,m ;
    IF NOT doneu THEN
       IF w IS NOT NULL AND  m IS NOT NULL AND (SELECT (SELECT COUNT(*) FROM notice WHERE NoticeId=w AND NoticeType='spare')=0) THEN
          INSERT INTO notice (RecId,LastModDateTime,LastModBy,CreatedDateTime,CreatedBy,NoticeId,LoginId,NoticeType) VALUES((SELECT REPLACE(UUID(),'-','')),SYSDATE(),'admin',SYSDATE(),'admin',w,m,'spare');
			 END IF;
    END IF;
  UNTIL doneu END REPEAT;
  CLOSE cur2;
END;

