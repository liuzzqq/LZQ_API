create definer = root@`%` view v_knowledge_base as
select `f`.`create_by` AS `loginid`, `f`.`knowledge_pattern` AS `knowledge_pattern`, count(0) AS `count_value`
from `iitsp_changping_new`.`knowledge_base` `f`
where (`f`.`knowledge_pattern` = '1')
group by `f`.`create_by`;

