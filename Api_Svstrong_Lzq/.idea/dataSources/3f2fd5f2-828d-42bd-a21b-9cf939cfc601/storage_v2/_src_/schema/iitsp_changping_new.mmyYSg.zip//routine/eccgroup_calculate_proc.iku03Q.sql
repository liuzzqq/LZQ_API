create
    definer = root@`%` procedure eccgroup_calculate_proc(IN in_groupid char(32), IN in_ifexpand bit,
                                                         IN in_belongid char(32), IN in_nodeid char(32))
BEGIN
    DECLARE pTemp TEXT;  
    DECLARE cTemp TEXT; 
	
    SET group_concat_max_len = 102400;
    
    DROP TEMPORARY TABLE IF EXISTS eccgroup_calculate_table;
    DROP TEMPORARY TABLE IF EXISTS eccgroup_calculate_tables; 
    
    IF in_nodeid IS NULL OR in_nodeid='se' THEN 
    
	SET in_nodeid = '';
    
    END IF;
   
    CREATE TEMPORARY TABLE eccgroup_calculate_table 
    SELECT DISTINCT
          b.status,b.groupname,
          IFNULL(a.machinecount,0) machinecount,
          IFNULL(c.monitorcount,0) monitorcount,
          IFNULL(a.machinegoodcount,0) machinegoodcount,
          IFNULL(a.machineerrorcount,0) machineerrorcount,
          IFNULL(c.monitorerrorcount,0) monitorerrorcount,
          IFNULL(c.monitorgoodcount,0) monitorgoodcount,
          IFNULL(c.monitorwarningcount,0) monitorwarningcount,
          IFNULL(c.monitordisabledcount,0) monitordisabledcount,
          b.description,
          b.lastmoddatetime,
          b.recid groupid,
          b.parentgroupid,
          b.belongid,
          b.Sorter
    FROM (
      SELECT DISTINCT groupId,COUNT(DISTINCT recid) machinecount,
           SUM(CASE WHEN equipment.EquipmentStatus = 'good' THEN 1 ELSE 0 END) AS machinegoodcount,
           SUM(CASE WHEN equipment.EquipmentStatus = 'error' THEN 1 ELSE 0 END) AS machineerrorcount           
      FROM `Equipment` equipment GROUP BY groupId
    ) a RIGHT JOIN `EccGroup` b
      ON a.groupId = b.recid LEFT JOIN (
      SELECT  groupId,COUNT(*) monitorcount ,
           SUM(CASE WHEN e.MonitorStatus = 'good' THEN 1 ELSE 0 END)  monitorgoodcount,
           SUM(CASE WHEN e.MonitorStatus = 'error' THEN 1 ELSE 0 END)  monitorerrorcount,
           SUM(CASE WHEN e.MonitorStatus='warning' THEN 1 ELSE 0 END)  monitorwarningcount,
           SUM(CASE WHEN e.MonitorStatus='disabled' THEN 1 ELSE 0 END)  monitordisabledcount
      FROM `Monitor` e  GROUP BY groupId
    ) c ON b.recid = c.groupId WHERE b.NodeId = in_nodeid;
    
    BEGIN
    
        DECLARE v_groupname VARCHAR(50);
        DECLARE v_groupid VARCHAR(50);
        DECLARE v_machinecount INT;
        DECLARE v_monitorcount INT;
        DECLARE v_machinegoodcount INT;
        DECLARE v_machineerrorcount INT;
        DECLARE v_monitorerrorcount INT;
        DECLARE v_monitorgoodcount INT;
        DECLARE v_monitorwarningcount INT;
        DECLARE v_monitordisabledcount INT;
        DECLARE v_description VARCHAR(100);
        
        DECLARE no_more_departments INT;
        DECLARE temp_groupid VARCHAR(32);	
        DECLARE temp_groupname VARCHAR(50);
	
	DECLARE group_cur CURSOR FOR
	SELECT groupid,groupname FROM eccgroup_calculate_table where parentgroupid=in_groupid;
	
	DECLARE CONTINUE HANDLER FOR 
	NOT FOUND SET no_more_departments=1;
	
	SET no_more_departments=0;
	
	OPEN group_cur;
	REPEAT
	FETCH group_cur INTO temp_groupid,temp_groupname;
          
          BEGIN
          
               IF NOT no_more_departments THEN
	       
	           SET cTemp =temp_groupid;
	           SET pTemp = '$'; 
		   WHILE cTemp IS NOT NULL DO  
		         SET pTemp = CONCAT(pTemp,',',cTemp);  
			 SELECT GROUP_CONCAT(groupid) INTO cTemp FROM eccgroup_calculate_table   
			 WHERE FIND_IN_SET(parentgroupid,cTemp)>0; 
		   END WHILE; 
		       
		   SELECT  IFNULL(SUM(machinecount),0),
			   IFNULL(SUM(monitorcount),0),
			   IFNULL(SUM(machinegoodcount),0),
			   IFNULL(SUM(machineerrorcount),0),
			   IFNULL(SUM(monitorerrorcount),0),
			   IFNULL(SUM(monitorgoodcount),0),
			   IFNULL(SUM(monitorwarningcount),0),
			   IFNULL(SUM(monitordisabledcount),0)
	           INTO    v_machinecount,
			   v_monitorcount,
			   v_machinegoodcount,
			   v_machineerrorcount,
			   v_monitorerrorcount,
			   v_monitorgoodcount,
			   v_monitorwarningcount,
			   v_monitordisabledcount
		   FROM    eccgroup_calculate_table WHERE FIND_IN_SET(groupid,pTemp); 
		   
	           UPDATE  eccgroup_calculate_table SET machinecount=v_machinecount,
							monitorcount=v_monitorcount,
							machinegoodcount=v_machinegoodcount,
							machineerrorcount=v_machineerrorcount,
							monitorerrorcount=v_monitorerrorcount,
							monitorgoodcount=v_monitorgoodcount,
							monitorwarningcount=v_monitorwarningcount,
							monitordisabledcount=v_monitordisabledcount
		   WHERE groupid = temp_groupid;
	       
               END IF;
               
      	  END;
	
	UNTIL no_more_departments 
	END REPEAT;
	CLOSE group_cur;
    END;
    
    CREATE TEMPORARY TABLE eccgroup_calculate_tables LIKE eccgroup_calculate_table;  	
 
    INSERT INTO eccgroup_calculate_tables
    SELECT '2','',SUM(machinecount),SUM(monitorcount),SUM(machinegoodcount),SUM(machineerrorcount),SUM(monitorerrorcount),
		  SUM(monitorgoodcount),SUM(monitorwarningcount),SUM(monitordisabledcount),'','1970-01-01','','','',0
    FROM eccgroup_calculate_table WHERE parentgroupid=in_groupid;
    
    SELECT *,2 sel_order FROM eccgroup_calculate_table WHERE parentgroupid=in_groupid
    UNION 
    SELECT *,1 sel_order FROM eccgroup_calculate_tables
    ORDER BY sel_order,Sorter,groupname;
    	
END;

