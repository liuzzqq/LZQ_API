create definer = root@`%` view v_relation_human_login as
select `iitsp_changping_new`.`app_relation_human`.`loginid` AS `loginid`, count(0) AS `count_value`
from `iitsp_changping_new`.`app_relation_human`
where (`iitsp_changping_new`.`app_relation_human`.`concerned_loginid` is not null)
group by `iitsp_changping_new`.`app_relation_human`.`loginid`;

