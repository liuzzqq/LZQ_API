create definer = root@`%` event reminding_the_number_of_spare on schedule
    every '60' MINUTE
        starts '2017-12-26 00:00:00'
    on completion preserve
    enable
    do
    call reminding_the_number_of_spare();

