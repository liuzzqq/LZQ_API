create
    definer = root@`%` procedure research_time_out()
BEGIN
	#Routine body goes here...
	DECLARE done INT DEFAULT 0;
	
  DECLARE i,w VARCHAR(64);
	
	DECLARE cur1 CURSOR FOR SELECT RecId,EndDateTime from  research where EndDateTime<SYSDATE();
	DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

	OPEN cur1; 
  REPEAT
    FETCH cur1 INTO i,w; 
    IF NOT done THEN
       IF i IS NOT NULL THEN
         UPDATE research set `Status` = 2 where RecId = i;
       END IF;
    END IF;
  UNTIL done END REPEAT;
  CLOSE cur1;
	 
END;

