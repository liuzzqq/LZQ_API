create definer = root@localhost event defaultscore on schedule
    every '60' MINUTE
        starts '2017-08-10 20:41:24'
    on completion preserve
    disable
    do
    call defaultscore();

