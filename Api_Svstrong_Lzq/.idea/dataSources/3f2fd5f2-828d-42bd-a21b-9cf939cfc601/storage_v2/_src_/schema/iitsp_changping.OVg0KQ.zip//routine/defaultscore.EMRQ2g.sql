create
    definer = root@`%` procedure defaultscore()
BEGIN
  DECLARE done INT DEFAULT 0;
  DECLARE i,w,c,d,r VARCHAR(32);
  DECLARE cur1 CURSOR FOR SELECT w.RecId,w.WorkOrderNumber,w.CreatedBy,p.DisplayName,ur.RoleId FROM workordercommon w LEFT JOIN Profile p ON p.LoginID=w.CreatedBy LEFT JOIN UserRole ur ON ur.UserId=w.CreatedBy WHERE w.status='dpj' AND w.WorkOrderNumber like 'GZ%' AND w.LastModDateTime<DATE_ADD(SYSDATE(),INTERVAL -2 DAY);
  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

  OPEN cur1;
  
  REPEAT
    FETCH cur1 INTO i,w,c,d,r;
	
    IF NOT done THEN
       IF w is not null THEN
          UPDATE workordercommon SET LastModBy=c,LastModDateTime=SYSDATE(),Score='100',CurrentHandle='',Status='gb' where WorkOrderNumber=w;
					INSERT INTO satisfaction(RecId,LastModDateTime,LastModBy,CreatedDateTime,CreatedBy,ServicesAging,TechnologicalLevel,FailureDescription,ServiceAttribute,ProductQuality,ServiceSuggestions,ConfirmTime,WorkOrderId,ReturnContent,ReturnPeople) VALUES ((SELECT REPLACE(UUID(),'-','')),SYSDATE(),c,SYSDATE(),c,5,5,5,5,0,'系统默认好评',SYSDATE(),i,'','');
					INSERT INTO workflowlog(RecId,LastModDateTime,LastModBy,CreatedDateTime,CreatedBy,FlowAction,LinkDesc,WorkOrderId,FromId,ToId,Step,Content,ProcessResult,Reasons,DispatchTime,ResolutionState,ArrivalTime,FromUser,ToUser,RemoteSolve,OpIdentity,FaultPicture,SpeechPath) VALUES ((SELECT REPLACE(UUID(),'-','')),SYSDATE(),c,SYSDATE(),c,'系统评价并关闭','',i,c,c,'3','系统默认好评','','',null,'',null,d,d,'',0,'',null);          
       END IF;
    END IF;
  UNTIL done END REPEAT;
  CLOSE cur1;
END;

