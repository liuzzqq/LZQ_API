create
    definer = root@`%` procedure eccequipment_calculate_proc(IN in_groupid varchar(50), IN in_ifexpand bit)
BEGIN
   DECLARE pTemp VARCHAR(1000);  
   DECLARE cTemp VARCHAR(1000);  -- 两个临时变量
   SET pTemp = '$';  
   SET cTemp =in_groupid;  -- 把rootId强制转换为字符。
   
   DROP TEMPORARY TABLE IF EXISTS eccequipment_calculate_table;
   DROP TEMPORARY TABLE IF EXISTS eccequipment_calculate_tables; 
   
   IF in_groupid = '' AND in_ifexpand = 0 THEN
       BEGIN
            SELECT '' blank FROM DUAL WHERE 1=0;
       END;
    ELSE
       BEGIN
            CREATE TEMPORARY TABLE eccequipment_calculate_table
	    SELECT 
	    Equipment.EquipmentStatus,Equipment.title,Equipment.serveraddress,Equipment.equipmenttype,
	    IFNULL(EccMonitorTotal.allcount,0) allcount,IFNULL(EccMonitorTotal.goodcount,0) goodcount,IFNULL(EccMonitorTotal.errorcount,0) errorcount,
	    IFNULL(EccMonitorTotal.warningcount,0) warningcount,IFNULL(EccMonitorTotal.disabledcount,0) disabledcount,
	    Equipment.RecId machineid,EccGroup.RecId groupid,EccGroup.ParentGroupId,Equipment.LastModDateTime,Equipment.connectiontype,Equipment.Sorter
	    FROM EccGroup,Equipment LEFT JOIN
	    (
	        SELECT  e.EquipmentId, 
	        COUNT(e.EquipmentId) allcount,
	        SUM(CASE e.MonitorStatus WHEN 'good' THEN 1 ELSE 0 END) AS goodcount, 
	        SUM(CASE e.MonitorStatus WHEN 'error' THEN 1 ELSE 0 END) AS errorcount,
	        SUM(CASE e.MonitorStatus WHEN 'warning' THEN 1 ELSE 0 END) AS warningcount,
	        SUM(CASE e.MonitorStatus WHEN 'disabled' THEN 1 ELSE 0 END) AS disabledcount
	        FROM Monitor e 
	        GROUP BY e.EquipmentId
	    ) AS EccMonitorTotal ON EccMonitorTotal.EquipmentId=Equipment.RecId
	    WHERE EccGroup.RecId=Equipment.GroupId;
	    
	    CREATE TEMPORARY TABLE eccequipment_calculate_tables LIKE eccequipment_calculate_table; 	
	    
            IF in_ifexpand = 1 THEN
                BEGIN
                      IF in_groupid = '' THEN
                          BEGIN
                         
                               INSERT INTO eccequipment_calculate_tables
                               SELECT '','','','',SUM(allcount),SUM(goodcount),SUM(errorcount),SUM(warningcount),SUM(disabledcount),'','','','1970-01-01','',0
                               FROM eccequipment_calculate_table
			       WHERE groupid = in_groupid;                         
                         
                               SELECT DISTINCT *,'',2 sel_order FROM eccequipment_calculate_table WHERE machineid IS NOT NULL 
                               UNION 
			       SELECT  *,'',1 sel_order FROM eccequipment_calculate_tables
			       ORDER BY sel_order,title;
			        
                          END;
                          
                      ELSE
                          BEGIN
				WHILE cTemp IS NOT NULL DO  
				   SET pTemp = CONCAT(pTemp,',',cTemp);  -- 把所有节点连接成字符串。
				   SELECT GROUP_CONCAT(groupid) INTO cTemp FROM eccequipment_calculate_table   
				   WHERE FIND_IN_SET(parentgroupid,cTemp)>0; 
				END WHILE; 
				
				INSERT INTO eccequipment_calculate_tables	
				SELECT '','','','',SUM(allcount),SUM(goodcount),SUM(errorcount),SUM(warningcount),SUM(disabledcount),'','','','1970-01-01','',0
                                FROM eccequipment_calculate_table
			        WHERE groupid = in_groupid;
			        
                                SELECT *,'',2 sel_order FROM eccequipment_calculate_table WHERE FIND_IN_SET(groupid,pTemp)
                                UNION 
			        SELECT *,'',1 sel_order FROM eccequipment_calculate_tables
			        ORDER BY sel_order,Sorter,title;			
   			           
                          END;
                      END IF;
                 END;
            ELSE
                 BEGIN
                 
		       WHILE cTemp IS NOT NULL DO  
		          SET pTemp = CONCAT(pTemp,',',cTemp);  -- 把所有节点连接成字符串。
		          SELECT GROUP_CONCAT(groupid) INTO cTemp FROM eccequipment_calculate_table   
		          WHERE FIND_IN_SET(parentgroupid,cTemp)>0; 
		       END WHILE; 
		       
		       INSERT INTO eccequipment_calculate_tables
		       SELECT '','','','',SUM(allcount),SUM(goodcount),SUM(errorcount),SUM(warningcount),SUM(disabledcount),'','','','1970-01-01','',0
		       FROM eccequipment_calculate_table
		       WHERE groupid = in_groupid;
		       
                       SELECT *,'',2 sel_order FROM eccequipment_calculate_table WHERE groupid = in_groupid AND FIND_IN_SET(groupid, pTemp) and machineid is not null
                       UNION 
		       SELECT *,'',1 sel_order FROM eccequipment_calculate_tables
		       ORDER BY sel_order,Sorter,title;	
                       
                 END;
            END IF;
            
       END;
    END IF;
	
END;

