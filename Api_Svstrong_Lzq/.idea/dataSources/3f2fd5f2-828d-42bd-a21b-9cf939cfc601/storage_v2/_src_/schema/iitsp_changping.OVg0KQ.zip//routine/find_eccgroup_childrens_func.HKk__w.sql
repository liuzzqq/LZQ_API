create
    definer = root@`%` function find_eccgroup_childrens_func(groupID varchar(32)) returns varchar(4000)
BEGIN
        DECLARE pTemp VARCHAR(4000);      
        DECLARE cTemp VARCHAR(4000); 
        
	SET cTemp =groupID;
	SET pTemp = '$'; 
	       
        WHILE cTemp IS NOT NULL DO  
	      SET pTemp = CONCAT(pTemp,',',cTemp);  
              SELECT GROUP_CONCAT(RecID) INTO cTemp FROM EccGroup   
	      WHERE FIND_IN_SET(ParentGroupId,cTemp)>0; 
	END WHILE; 
	
        RETURN 	pTemp;
	
    END;

