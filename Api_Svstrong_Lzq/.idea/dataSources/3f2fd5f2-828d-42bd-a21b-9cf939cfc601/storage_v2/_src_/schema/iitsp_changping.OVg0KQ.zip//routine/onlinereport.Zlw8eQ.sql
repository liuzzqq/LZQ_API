create
    definer = root@`%` procedure onlinereport()
BEGIN
  DECLARE done INT DEFAULT 0;
  DECLARE doneu INT DEFAULT 0;
  DECLARE c,d,e,h,j,k,l,m  VARCHAR(32);/*allcount单位下所有绑定的设备 noPingcount 绑定的设备没有Ping  notOnlineCount 不在线数量 OnlineCount 在线数量 mcount 维修数量 mrate 单位维修率 onlineRate  在线率  */
  DECLARE i,w VARCHAR(32);
  DECLARE cur1 CURSOR FOR SELECT  IF((CASE WHEN (LOCATE("PERCENT_GOOD",MonitorValue)=1) THEN SUBSTR(MonitorValue FROM 14 FOR (POSITION("," IN MonitorValue))-14) WHEN  (LOCATE("PERCENT_GOOD",MonitorValue)=2) THEN  SUBSTR(MonitorValue FROM 33 FOR  (CHAR_LENGTH(MonitorValue)-33)) END)>0,'1','0')mvalue,Assetsid from monitor m, equipmentassets eqs WHERE m.EquipmentId = eqs.EquipmentId AND MonitorType='Ping';
	DECLARE cur2 CURSOR FOR 
	SELECT a.UseUnitId,a.allcount,b.havePingcount,
	(CASE WHEN e.nopingCount IS NULL THEN 0 WHEN  e.nopingCount IS NOT NULL THEN e.nopingCount END) noPingCount,
 /* (CASE WHEN b.notOneLincount IS NULL THEN 0 WHEN  b.notOneLincount IS NOT NULL THEN b.notOneLincount END) notOneLincount,*/
  (CASE WHEN c.OneLincount IS NULL THEN 0 WHEN c.OneLincount IS NOT NULL THEN c.OneLincount END )OneLincount,
	(CASE WHEN d.mCount IS NULL THEN 0 WHEN  d.mCount IS NOT NULL THEN d.mCount END) mCount ,
  round((CASE WHEN mCount/a.allcount IS NULL THEN 0 WHEN  mCount/a.allcount IS NOT NULL THEN mCount/a.allcount END)*100,2) mrate,
  round((CASE WHEN OneLincount/b.havePingcount IS NULL THEN 0 WHEN OneLincount/b.havePingcount IS NOT NULL THEN  OneLincount/b.havePingcount END)*100,2) onlineRate 
	FROM (SELECT COUNT(*) allcount,h.UseUnitId,u.`Name` from  hardwareassets h,equipmentassets e,unit u  WHERE h.RecId = e.AssetsId AND h.UseUnitId = u.RecId GROUP BY h.UseUnitId) a 
  LEFT JOIN (SELECT COUNT(*) havePingcount,u.RecId FROM hardwareassets h,unit u WHERE h.UseUnitId = u.RecId AND (h.IsActive ='0' OR h.IsActive ='1')  GROUP BY h.UseUnitId)b ON a.UseUnitId = b.RecId 
	LEFT JOIN(SELECT COUNT(*)OneLincount,u.RecId FROM hardwareassets h,unit u WHERE h.UseUnitId = u.RecId AND h.IsActive ='1'  GROUP BY h.UseUnitId )c  ON a.UseUnitId = c.RecId
	LEFT JOIN(SELECT COUNT(*)mCount,u.RecId FROM hardwareassets h,equipmentassets es,unit u,assetsstatus ast WHERE h.RecId = es.AssetsId AND h.UseUnitId = u.RecId AND h.AssetStates = ast.RecId AND ast.StatusName='维修'  GROUP BY h.UseUnitId )d  ON a.UseUnitId = d.RecId
	LEFT JOIN (SELECT COUNT(*) nopingCount,u.RecId FROM hardwareassets h,unit u,equipmentassets es WHERE h.UseUnitId = u.RecId AND h.RecId = es.AssetsId AND h.IsActive IS NULL  GROUP BY h.UseUnitId)e ON a.UseUnitId = e.RecId ;
  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET  done = 1,doneu = 1;
  	
  OPEN cur1;
  
  REPEAT
    FETCH cur1 INTO i,w;
    IF NOT done THEN
       IF w is not null THEN
          UPDATE hardwareassets SET LastModDateTime=SYSDATE(),IsActive=i WHERE RecId=w;
       END IF;
    END IF;
  UNTIL done END REPEAT;
  CLOSE cur1;

	SET doneu = 0;
	OPEN cur2;
  
  REPEAT
    FETCH cur2 INTO c,d,e,h,j,k,l,m ;
    IF NOT doneu THEN
       IF w is not null THEN
          UPDATE unit SET LastModDateTime=SYSDATE(),BindAssetsCount=d,HavePingCount=e,NoPingCount=h,OnlineCount=j,MaintenanceCount=k,OnlineRate=l,MaintenanceRate=m WHERE RecId =c;
       END IF;
    END IF;
  UNTIL doneu END REPEAT;
  CLOSE cur2;
END;

