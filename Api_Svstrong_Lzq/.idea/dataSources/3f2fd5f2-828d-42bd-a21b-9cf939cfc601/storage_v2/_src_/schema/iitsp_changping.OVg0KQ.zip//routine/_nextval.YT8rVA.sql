create
    definer = root@`%` function _nextval(name varchar(50)) returns int
begin    
declare _cur int;  
declare _maxvalue int;  -- 接收最大值  
declare _minvalue int;  -- 接收最大值  
declare _increment int; -- 接收增长步数  
declare _dateline varchar(10); -- 判断每日取新号
set _increment = (select increment_val from tbl_sequence where seq_name = name);  
set _maxvalue = (select max_value from tbl_sequence where seq_name = name);  
set _minvalue = (select min_value from tbl_sequence where seq_name = name); 
set _cur = (select current_val from tbl_sequence where seq_name = name);    
set _dateline = (select DATE_FORMAT(date_line,'%Y-%m-%d') from tbl_sequence where seq_name = name);
if(DATE_FORMAT(now(),'%Y-%m-%d')>_dateline) THEN
set _cur=_minvalue;
update tbl_sequence                      -- 更新当前值  
 set current_val = min_value + increment_val,date_line=now()   
 where seq_name = name ;   
else 
 update tbl_sequence                      -- 更新当前值  
 set current_val = _cur + increment_val    
 where seq_name = name ; 
end if;

   
if(_cur + _increment >= _maxvalue) then  -- 判断是都达到最大值  
      update tbl_sequence    
        set current_val = min_value    
        where seq_name = name ;  
end if;  
return _cur;    
end;

