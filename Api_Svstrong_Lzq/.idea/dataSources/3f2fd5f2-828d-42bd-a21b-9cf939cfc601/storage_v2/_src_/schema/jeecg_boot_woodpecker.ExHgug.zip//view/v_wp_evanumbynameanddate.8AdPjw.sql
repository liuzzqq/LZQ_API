create definer = root@`%` view v_wp_evanumbynameanddate as
select `t`.`name` AS `name`, `t`.`num` AS `num`, `t`.`createTime` AS `createTime`
from (select `a`.`repair_id` AS `name`, count(0) AS `num`, substr(`a`.`create_time`, 1, 10) AS `createTime`
      from `jeecg_boot_woodpecker`.`se_order` `a`
      where (`a`.`evalute_grade` = 1)
      group by `a`.`repair_id`, substr(`a`.`create_time`, 1, 10)
      union all
      select `a`.`repair_id` AS `name`, count(0) AS `num`, substr(`a`.`create_time`, 1, 10) AS `createTime`
      from `jeecg_boot_woodpecker`.`se_task` `a`
      where (`a`.`evalute_grade` = 1)
      group by `a`.`repair_id`, substr(`a`.`create_time`, 1, 10)) `t`
group by `t`.`name`, `t`.`createTime`;

