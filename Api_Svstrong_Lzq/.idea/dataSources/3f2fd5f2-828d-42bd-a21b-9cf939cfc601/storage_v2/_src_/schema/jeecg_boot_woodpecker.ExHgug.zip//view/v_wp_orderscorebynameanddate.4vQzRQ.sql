create definer = root@`%` view v_wp_orderscorebynameanddate as
select `jeecg_boot_woodpecker`.`se_order`.`repair_id`                                                                AS `name`,
       (case
            when (timestampdiff(HOUR, `jeecg_boot_woodpecker`.`se_order`.`order_time`,
                                `jeecg_boot_woodpecker`.`se_order`.`complete_time`) > 48) then '0	'
            when (timestampdiff(HOUR, `jeecg_boot_woodpecker`.`se_order`.`order_time`,
                                `jeecg_boot_woodpecker`.`se_order`.`complete_time`) between 24 and 48) then '60'
            when (timestampdiff(HOUR, `jeecg_boot_woodpecker`.`se_order`.`order_time`,
                                `jeecg_boot_woodpecker`.`se_order`.`complete_time`) between 4 and 24) then '80'
            when (timestampdiff(HOUR, `jeecg_boot_woodpecker`.`se_order`.`order_time`,
                                `jeecg_boot_woodpecker`.`se_order`.`complete_time`) between 0 and 4)
                then '100' end)                                                                                      AS `score`,
       substr(`jeecg_boot_woodpecker`.`se_order`.`create_time`, 1, 10)                                               AS `createTime`
from `jeecg_boot_woodpecker`.`se_order`
where ((`jeecg_boot_woodpecker`.`se_order`.`complete_time` is not null) and
       (`jeecg_boot_woodpecker`.`se_order`.`order_time` is not null))
group by `jeecg_boot_woodpecker`.`se_order`.`repair_id`, `jeecg_boot_woodpecker`.`se_order`.`create_time`;

