create definer = root@`%` trigger tr_update_user
    after update
    on sys_user
    for each row
BEGIN
    UPDATE swsc_raccon_back.sys_user
			SET password=new.password,salt=new.salt,email=new.email,status=new.status,mobile=new.phone,real_name=new.realname,user_icon=new.avatar
     WHERE account = new.username;
END;

