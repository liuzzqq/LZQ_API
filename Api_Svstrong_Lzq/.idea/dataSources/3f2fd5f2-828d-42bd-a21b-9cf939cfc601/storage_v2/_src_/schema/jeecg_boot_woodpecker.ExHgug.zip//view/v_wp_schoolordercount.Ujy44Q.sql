create definer = root@`%` view v_wp_schoolordercount as
select `ss`.`suoxie`                                                               AS `schoolName`,
       count(`so`.`id`)                                                            AS `totalNum`,
       sum((case when (`so`.`status` = 1) then 1 else 0 end))                      AS `missNum`,
       sum((case when (`so`.`status` = 2) then 1 else 0 end))                      AS `proNum`,
       sum((case when (`so`.`status` = 2) then 1 else 0 end))                      AS `completeNum`,
       (sum((case when (`so`.`status` = 2) then 1 else 0 end)) / count(`so`.`id`)) AS `rate`
from (`jeecg_boot_woodpecker`.`se_school` `ss`
         left join `jeecg_boot_woodpecker`.`se_order` `so` on ((`so`.`school_code` = `ss`.`school_code`)))
group by `ss`.`suoxie`;

