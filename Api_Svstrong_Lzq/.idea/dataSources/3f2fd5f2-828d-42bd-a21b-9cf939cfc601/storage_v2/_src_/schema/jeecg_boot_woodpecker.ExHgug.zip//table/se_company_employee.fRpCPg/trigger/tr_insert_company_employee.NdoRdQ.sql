create definer = root@`%` trigger tr_insert_company_employee
    after insert
    on se_company_employee
    for each row
BEGIN
    INSERT INTO
      swsc_raccon_back.se_company_employee(id,company_code,account,type)
    VALUES
      (new.id,if(new.company_code='678','030ae062061d4cd986a0aeb3ba633773',new.company_code), new.user_id,new.type);
END;

