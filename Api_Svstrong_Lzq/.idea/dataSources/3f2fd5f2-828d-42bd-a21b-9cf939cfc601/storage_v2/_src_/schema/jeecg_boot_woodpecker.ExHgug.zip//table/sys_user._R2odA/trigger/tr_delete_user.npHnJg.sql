create definer = root@`%` trigger tr_delete_user
    after delete
    on sys_user
    for each row
BEGIN
  DELETE FROM swsc_raccon_back.sys_user WHERE account = old.username;
END;

