create definer = root@`%` trigger tr_insert_userconfig
    after insert
    on se_user_config
    for each row
BEGIN
    INSERT INTO
      swsc_raccon_back.se_user_config(id,account,openid,type)
    VALUES
      (new.id,new.user_id,new.openid,new.type);
END;

