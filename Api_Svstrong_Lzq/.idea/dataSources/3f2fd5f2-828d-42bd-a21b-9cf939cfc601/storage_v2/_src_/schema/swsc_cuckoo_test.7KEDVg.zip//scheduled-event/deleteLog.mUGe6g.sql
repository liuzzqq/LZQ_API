create definer = root@`%` event deleteLog on schedule
    every '1' DAY
        starts '2019-09-25 11:51:07'
    on completion preserve
    enable
    comment '删除7天前的访问日志数据'
    do
    BEGIN  
  DELETE FROM bs_access_log where access_time < DATE_SUB(CURDATE(),INTERVAL 7 DAY);
END;

