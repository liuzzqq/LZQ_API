create definer = root@`%` view sw_staff as
select '接触过湖北地区人员'         AS `type`,
       1                   AS `types`,
       `a`.`report_date`   AS `report_date`,
       `a`.`school_name`   AS `school_name`,
       `a`.`name`          AS `name`,
       '未知'                AS `gender`,
       '未知'                AS `age`,
       `a`.`contact_phone` AS `contact_phone`,
       `a`.`teacher`       AS `teacher`,
       `a`.`fzb_teacher`   AS `teacher_fzb`,
       `a`.`student`       AS `student`,
       `a`.`school_code`   AS `school_code`,
       `a`.`health_info`   AS `health_info`,
       `a`.`live_place`    AS `live_place`,
       ''                  AS `return_vehicle`,
       ''                  AS `return_date`,
       ''                  AS `stoppage`,
       ''                  AS `leave_vehicle`,
       ''                  AS `leave_date`,
       `a`.`remark`        AS `remark`,
       `a`.`make_info`     AS `make_info`,
       '3'                 AS `stoppage_type`,
       `a`.`native_place`  AS `native_place`
from `yqfk`.`sw_ncov_hubei` `a`
where ((`a`.`school_code` is not null) and
       ((`a`.`report_date` = convert(date_format(curdate(), '%Y-%m-%d') using utf8)) or
        (`a`.`report_date` = convert(date_format((curdate() - interval 1 day), '%Y-%m-%d') using utf8)) or
        (`a`.`report_date` = convert(date_format((curdate() + interval 1 day), '%Y-%m-%d') using utf8))))
union all
select '密切接触'              AS `type`,
       2                   AS `types`,
       `a`.`report_date`   AS `report_date`,
       `a`.`school_name`   AS `school_name`,
       `a`.`name`          AS `name`,
       `a`.`gender`        AS `gender`,
       `a`.`age`           AS `age`,
       `a`.`contact_phone` AS `contact_phone`,
       `a`.`teacher`       AS `teacher`,
       `a`.`fzb_teacher`   AS `teacher_fzb`,
       `a`.`student`       AS `student`,
       `a`.`school_code`   AS `school_code`,
       `a`.`health_info`   AS `health_info`,
       `a`.`live_place`    AS `live_place`,
       ''                  AS `return_vehicle`,
       ''                  AS `return_date`,
       ''                  AS `stoppage`,
       ''                  AS `leave_vehicle`,
       ''                  AS `leave_date`,
       `a`.`remark`        AS `remark`,
       `a`.`make_info`     AS `make_info`,
       '3'                 AS `stoppage_type`,
       `a`.`native_place`  AS `native_place`
from `yqfk`.`sw_ncov_intimate` `a`
where ((`a`.`report_date` = convert(date_format(curdate(), '%Y-%m-%d') using utf8)) or
       (`a`.`report_date` = convert(date_format((curdate() - interval 1 day), '%Y-%m-%d') using utf8)) or
       (`a`.`report_date` = convert(date_format((curdate() + interval 1 day), '%Y-%m-%d') using utf8)))
union all
select '疑似或确诊病例情况'         AS `type`,
       5                   AS `types`,
       `a`.`report_date`   AS `report_date`,
       `a`.`school_name`   AS `school_name`,
       `a`.`name`          AS `name`,
       `a`.`gender`        AS `gender`,
       `a`.`age`           AS `age`,
       `a`.`contact_phone` AS `contact_phone`,
       `a`.`teacher`       AS `teacher`,
       `a`.`fzb_teacher`   AS `teacher_fzb`,
       `a`.`student`       AS `student`,
       `a`.`school_code`   AS `school_code`,
       ''                  AS `health_info`,
       `a`.`live_place`    AS `live_place`,
       ''                  AS `return_vehicle`,
       ''                  AS `return_date`,
       ''                  AS `stoppage`,
       ''                  AS `leave_vehicle`,
       ''                  AS `leave_date`,
       `a`.`remark`        AS `remark`,
       ''                  AS `make_info`,
       '3'                 AS `stoppage_type`,
       ''                  AS `native_place`
from `yqfk`.`sw_ncov_person` `a`
where ((`a`.`report_date` = convert(date_format(curdate(), '%Y-%m-%d') using utf8)) or
       (`a`.`report_date` = convert(date_format((curdate() - interval 1 day), '%Y-%m-%d') using utf8)) or
       (`a`.`report_date` = convert(date_format((curdate() + interval 1 day), '%Y-%m-%d') using utf8)));

