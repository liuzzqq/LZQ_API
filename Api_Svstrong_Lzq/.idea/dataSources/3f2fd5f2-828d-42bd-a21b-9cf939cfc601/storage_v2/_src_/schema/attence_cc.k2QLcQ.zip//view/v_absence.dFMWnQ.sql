create definer = root@`%` view v_absence as
select count(distinct `attence_cc`.`sw_attence_record`.`user_id`) AS `number`,
       `attence_cc`.`sw_attence_record`.`class_id`                AS `meettingCode`
from `attence_cc`.`sw_attence_record`
where (`attence_cc`.`sw_attence_record`.`absence` = '1')
group by `attence_cc`.`sw_attence_record`.`class_id`;

