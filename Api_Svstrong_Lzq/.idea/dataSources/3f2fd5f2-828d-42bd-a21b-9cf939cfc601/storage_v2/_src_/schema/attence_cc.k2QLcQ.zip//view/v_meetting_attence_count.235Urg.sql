create definer = root@`%` view v_meetting_attence_count as
select count(distinct `attence_cc`.`sw_meetting_user`.`user_id`) AS `count`,
       `attence_cc`.`sw_meetting_user`.`class_id`                AS `class_id`
from `attence_cc`.`sw_meetting_user`
group by `attence_cc`.`sw_meetting_user`.`class_id`;

