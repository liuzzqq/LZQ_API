create definer = root@`%` view v_meetting_attence_confirm as
select count(distinct `attence_cc`.`sw_meetting_user`.`user_id`) AS `number`,
       `attence_cc`.`sw_meetting_user`.`class_id`                AS `class_id`
from `attence_cc`.`sw_meetting_user`
where (`attence_cc`.`sw_meetting_user`.`is_confirm` = '1')
group by `attence_cc`.`sw_meetting_user`.`class_id`;

