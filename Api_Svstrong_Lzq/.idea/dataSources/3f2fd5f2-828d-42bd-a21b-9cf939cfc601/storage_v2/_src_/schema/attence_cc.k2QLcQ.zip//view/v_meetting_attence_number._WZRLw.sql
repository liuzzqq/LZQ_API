create definer = root@`%` view v_meetting_attence_number as
select count(distinct `attence_cc`.`sw_attence_record`.`user_id`) AS `number1`,
       `attence_cc`.`sw_attence_record`.`class_id`                AS `class_id`
from `attence_cc`.`sw_attence_record`
where (`attence_cc`.`sw_attence_record`.`absence` = '0')
group by `attence_cc`.`sw_attence_record`.`class_id`;

