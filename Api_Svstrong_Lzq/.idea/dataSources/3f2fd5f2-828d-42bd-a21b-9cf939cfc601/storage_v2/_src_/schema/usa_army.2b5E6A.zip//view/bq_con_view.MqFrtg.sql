create definer = root@`%` view bq_con_view as
select distinct `a`.`con_amount`                                                                                 AS `con_amount`,
                `a`.`id`                                                                                         AS `id`,
                substring_index(substring_index(`a`.`contractor_cn`, '；', (`b`.`help_topic_id` + 1)), '；',
                                -(1))                                                                            AS `contractor_name`
from (`usa_army`.`v2` `a`
         join `mysql`.`help_topic` `b` on ((`b`.`help_topic_id` < ((length(`a`.`contractor_cn`) -
                                                                    length(replace(`a`.`contractor_cn`, '；', ''))) +
                                                                   1))));

