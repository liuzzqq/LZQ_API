create definer = root@`%` view v2 as
select `usa_army`.`bq_con`.`id`            AS `id`,
       `usa_army`.`bq_con`.`con_amount`    AS `con_amount`,
       `usa_army`.`bq_con`.`contractor_cn` AS `contractor_cn`
from `usa_army`.`bq_con`
where ((`usa_army`.`bq_con`.`equip_type` <> '') and (`usa_army`.`bq_con`.`equip_type` is not null));

