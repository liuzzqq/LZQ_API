create definer = root@`%` view bq_con_equip as
select distinct `a`.`con_amount`                                                                              AS `con_amount`,
                `a`.`id`                                                                                      AS `id`,
                `a`.`contractor_cn`                                                                           AS `contractor_cn`,
                substring_index(substring_index(`a`.`equip_type`, '；', (`b`.`help_topic_id` + 1)), '；',
                                -(1))                                                                         AS `equip_type`
from (`usa_army`.`v1` `a`
         join `mysql`.`help_topic` `b` on ((`b`.`help_topic_id` <
                                            ((length(`a`.`equip_type`) - length(replace(`a`.`equip_type`, '；', ''))) +
                                             1))));

