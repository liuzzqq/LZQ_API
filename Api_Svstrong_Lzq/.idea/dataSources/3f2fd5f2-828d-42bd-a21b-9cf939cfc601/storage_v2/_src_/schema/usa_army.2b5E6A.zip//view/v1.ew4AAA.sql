create definer = root@`%` view v1 as
select `usa_army`.`bq_con`.`id`            AS `id`,
       `usa_army`.`bq_con`.`contractor_cn` AS `contractor_cn`,
       `usa_army`.`bq_con`.`con_amount`    AS `con_amount`,
       `usa_army`.`bq_con`.`equip_type`    AS `equip_type`
from `usa_army`.`bq_con`
where ((`usa_army`.`bq_con`.`equip_type` <> '') and (`usa_army`.`bq_con`.`equip_type` is not null));

