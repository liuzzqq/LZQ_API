create
    definer = root@`%` function getChildList(rootId varchar(10000)) returns varchar(10000)
BEGIN
DECLARE pTemp VARCHAR(1000);  
       DECLARE cTemp VARCHAR(10000);   
       SET pTemp = '$';  
       SET cTemp = rootId;   
      
       WHILE cTemp is not null DO  
         SET pTemp = concat(pTemp,',',cTemp);   
         SELECT group_concat(id) INTO cTemp FROM hy_element   
         WHERE FIND_IN_SET(parent_id,cTemp)>0;

       END WHILE;  
       RETURN pTemp;  
END;

