create definer = root@`%` view user_position as
select `a`.`id`                                                            AS `id`,
       `a`.`username`                                                      AS `username`,
       `a`.`realname`                                                      AS `realname`,
       concat('(', `a`.`positionName`, ')')                                AS `pName`,
       (case
            when isnull(`a`.`positionName`) then concat(`a`.`realname`, '(暂无职位)')
            else concat(`a`.`realname`, '(', `a`.`positionName`, ')') end) AS `upname`
from (select `u`.`id`                               AS `id`,
             `u`.`username`                         AS `username`,
             `u`.`realname`                         AS `realname`,
             group_concat(`p`.`name` separator ',') AS `positionName`
      from ((`swsc_aqxj`.`sys_user` `u` left join `swsc_aqxj`.`sys_user_position` `up` on ((`u`.`id` = `up`.`user_id`)))
               left join `swsc_aqxj`.`sys_position` `p` on ((`up`.`position_id` = `p`.`id`)))
      group by `u`.`id`) `a`;

