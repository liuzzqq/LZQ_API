create definer = root@`%` view date_dual as
select (curdate() - interval weekday(curdate()) day)          AS `weekStart`,
       (curdate() - interval (weekday(curdate()) - 6) day)    AS `weekEnd`,
       (curdate() - interval (dayofmonth(curdate()) - 1) day) AS `monthStart`,
       last_day(curdate())                                    AS `monthEnd`;

