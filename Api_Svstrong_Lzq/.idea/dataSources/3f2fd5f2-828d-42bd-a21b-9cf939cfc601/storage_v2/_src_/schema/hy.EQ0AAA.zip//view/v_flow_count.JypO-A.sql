create definer = root@`%` view v_flow_count as
select `b`.`process_type_id` AS `process_type_id`, count(0) AS `count`
from (`hy`.`hy_process_rule` `a`
         left join `hy`.`hy_process` `b` on ((`b`.`process_type_id` = `a`.`rule_code`)))
group by `b`.`process_type_id`;

