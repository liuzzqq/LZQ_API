create definer = root@`%` trigger tr_delete_user
    after delete
    on sys_user
    for each row
BEGIN
  DELETE FROM swsc_aqxj_test.sys_user WHERE username = old.account;
END;

