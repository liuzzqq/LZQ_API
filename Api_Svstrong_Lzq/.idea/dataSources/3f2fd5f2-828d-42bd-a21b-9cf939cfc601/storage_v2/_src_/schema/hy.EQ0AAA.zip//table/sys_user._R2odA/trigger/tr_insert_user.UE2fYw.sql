create definer = root@`%` trigger tr_insert_user
    after insert
    on sys_user
    for each row
BEGIN
    INSERT INTO
      swsc_aqxj_test.sys_user(id,username,password,phone,realname,school_code)
    VALUES
      (MD5(RAND()*10000),new.account,new.password,new.mobile,new.real_name,new.department_id);
END;

