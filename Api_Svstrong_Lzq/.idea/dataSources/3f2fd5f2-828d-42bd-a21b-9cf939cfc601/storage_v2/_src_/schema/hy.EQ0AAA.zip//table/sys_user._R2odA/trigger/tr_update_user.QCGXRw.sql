create definer = root@`%` trigger tr_update_user
    after update
    on sys_user
    for each row
BEGIN
    UPDATE swsc_aqxj_test.sys_user
			SET password=new.password,phone=new.mobile,realname=new.real_name
     WHERE username = new.account;
END;

