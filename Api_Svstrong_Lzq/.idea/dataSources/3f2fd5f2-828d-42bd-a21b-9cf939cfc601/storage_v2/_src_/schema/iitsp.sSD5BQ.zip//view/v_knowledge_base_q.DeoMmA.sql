create definer = root@`%` view v_knowledge_base_q as
select `f`.`create_by` AS `loginid`, `f`.`knowledge_pattern` AS `knowledge_pattern`, count(0) AS `count_value`
from `iitsp`.`knowledge_base` `f`
where (`f`.`knowledge_pattern` = '0')
group by `f`.`create_by`;

