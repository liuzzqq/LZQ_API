create
    definer = root@`%` function demo(id varchar(32)) returns varchar(8000)
BEGIN
		DECLARE pTemp VARCHAR(4000);      
		DECLARE cTemp VARCHAR(4000); 
		
		SET cTemp = id;
		SET pTemp = '$'; 
		       
		WHILE cTemp IS NOT NULL DO  
		      SET pTemp = CONCAT(pTemp,',',cTemp);  
		      SELECT GROUP_CONCAT(o_code) INTO cTemp FROM Organization   
		      WHERE FIND_IN_SET(parentId,cTemp)>0; 
		END WHILE; 
		
		RETURN 	pTemp;
	
    END;

