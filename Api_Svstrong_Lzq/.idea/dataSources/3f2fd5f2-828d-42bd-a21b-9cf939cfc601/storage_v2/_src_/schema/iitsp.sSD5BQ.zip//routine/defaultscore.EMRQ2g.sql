create
    definer = root@`%` procedure defaultscore() comment '48 小时自动好评，默认评分60分，并在满意度表和工单日志表插入对应的数据'
BEGIN 
DECLARE done INT DEFAULT 0;
DECLARE i, w, c, d, r VARCHAR (32);
DECLARE cur1 CURSOR FOR SELECT
	w.id,
	w.work_order_number,
	w.create_by,
	p.username,
	p.last_used_role
FROM
	work_order_common w
LEFT JOIN sys_user p ON p.loginid = w.create_by 
WHERE
	w.status = 6 AND w.work_order_number LIKE 'GZ%' AND w.modify_date_time < DATE_ADD(SYSDATE(), INTERVAL - 2 DAY);
DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1;

 OPEN cur1;
  
  REPEAT
    FETCH cur1 INTO i,w,c,d,r;
    IF NOT done THEN
       IF w is not null THEN
          UPDATE work_order_common SET modify_by=c,modify_date_time=SYSDATE(),score='60', `status`=7 where id=i;
					INSERT INTO work_order_satisfaction(  modify_by, create_by,time_to_service,technological_level,failure_description,service_attribute, service_suggestions, work_order_id,who_do_this,who_do_what) VALUES (  c, c,3,3,3,3,  '系统默认好评', i,'0','客户评价');
					INSERT INTO workflow_log(modify_by,create_by,flow_action,work_order_id,from_id,current_handler_id,dispatch_time ) VALUES ( c, c,'系统评价并关闭', i,c,c,NOW());          
       END IF;
    END IF;
  UNTIL done END REPEAT;
  CLOSE cur1;
END;

