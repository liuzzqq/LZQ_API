create
    definer = root@v2yunwei procedure monitor_backout_workorder()
BEGIN
  DECLARE done INT DEFAULT 0;
 
  DECLARE i,w VARCHAR(64); 
	DECLARE cur1 CURSOR FOR SELECT  LastModBy,WorkOrderId FROM workflowlog wl WHERE     wl.FlowAction LIKE '%回退%' AND wl.FromId='工程师' and  wl.IsView ='1'  ; 
  DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET done = 1 ;  
  OPEN cur1; 
  REPEAT
    FETCH cur1 INTO i,w; 
    IF NOT done THEN
       IF i IS NOT NULL THEN
         UPDATE WorkOrderCommon SET NoVisibleman = (CASE WHEN (NoVisibleman IS NULL OR NoVisibleman ='') THEN i WHEN NOT FIND_IN_SET(i,NoVisibleman) THEN CONCAT(NoVisibleman,",",i) ELSE NoVisibleman END  ) WHERE RecId=w;
       END IF;
    END IF;
  UNTIL done END REPEAT;
  CLOSE cur1; 
END;

