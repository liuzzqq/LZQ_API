create definer = root@`%` view v_relation_human_login as
select `iitsp`.`app_relation_human`.`loginid` AS `loginid`, count(0) AS `count_value`
from `iitsp`.`app_relation_human`
where (`iitsp`.`app_relation_human`.`concerned_loginid` is not null)
group by `iitsp`.`app_relation_human`.`loginid`;

