create definer = root@`%` view v_relation_human_con as
select `iitsp`.`app_relation_human`.`concerned_loginid` AS `loginid`, count(0) AS `count_value`
from `iitsp`.`app_relation_human`
group by `iitsp`.`app_relation_human`.`concerned_loginid`;

