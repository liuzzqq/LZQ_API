create definer = root@`%` view org_relation_view as
select `tgroup`.`name_`                              AS `groupName`,
       `tuser`.`fullname_`                           AS `userName`,
       `role`.`name_`                                AS `roleName`,
       concat(`tgroup`.`name_`, '-', `role`.`name_`) AS `postName`,
       concat(`tgroup`.`id_`, '-', `role`.`id_`)     AS `postId`,
       `relation`.`id_`                              AS `id_`,
       `relation`.`group_id_`                        AS `group_id_`,
       `relation`.`user_id_`                         AS `user_id_`,
       `relation`.`is_master_`                       AS `is_master_`,
       `relation`.`role_id_`                         AS `role_id_`,
       `relation`.`status_`                          AS `status_`,
       `relation`.`type_`                            AS `type_`,
       `relation`.`create_time_`                     AS `create_time_`,
       `relation`.`create_by_`                       AS `create_by_`,
       `relation`.`update_time_`                     AS `update_time_`,
       `relation`.`update_by_`                       AS `update_by_`
from (((`swsw_nikong`.`org_relation` `relation` left join `swsw_nikong`.`org_user` `tuser` on ((`relation`.`user_id_` = `tuser`.`id_`))) left join `swsw_nikong`.`org_group` `tgroup` on ((`relation`.`group_id_` = `tgroup`.`id_`)))
         left join `swsw_nikong`.`org_role` `role` on ((`relation`.`role_id_` = `role`.`id_`)));

