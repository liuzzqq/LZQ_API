create definer = root@`%` view v_moraledu_record as
select `swsc_cuckoo_bjxx`.`bs_moral_edu_record`.`facukty_type`        AS `facuktyType`,
       `swsc_cuckoo_bjxx`.`bs_moral_edu_record`.`grade_id`            AS `gradeId`,
       `swsc_cuckoo_bjxx`.`bs_moral_edu_record`.`group_id`            AS `groupId`,
       `swsc_cuckoo_bjxx`.`bs_moral_edu_record`.`item_id`             AS `itemId`,
       sum(`swsc_cuckoo_bjxx`.`bs_moral_edu_record`.`score`)          AS `totalScore`,
       week(`swsc_cuckoo_bjxx`.`bs_moral_edu_record`.`check_date`, 3) AS `week`,
       year(`swsc_cuckoo_bjxx`.`bs_moral_edu_record`.`check_date`)    AS `year`
from `swsc_cuckoo_bjxx`.`bs_moral_edu_record`
where (`swsc_cuckoo_bjxx`.`bs_moral_edu_record`.`item_level` = 1)
group by `week`, `swsc_cuckoo_bjxx`.`bs_moral_edu_record`.`group_id`,
         `swsc_cuckoo_bjxx`.`bs_moral_edu_record`.`item_id`;

