create definer = root@`%` view v_employ as
select `a`.`uni_code` AS `uni_code`, if((count(`b`.`id`) > 0), '1', '0') AS `dy`
from (`parade_2019`.`bm_equip_list` `a`
         left join `parade_2019`.`bm_equip_employ` `b` on (((`b`.`available_date` like convert(
        concat(date_format((now() - interval 1 day), '%Y-%m-%d'), '%') using utf8)) and
                                                            (`a`.`uni_code` = `b`.`uni_code`))))
group by `a`.`uni_code`;

