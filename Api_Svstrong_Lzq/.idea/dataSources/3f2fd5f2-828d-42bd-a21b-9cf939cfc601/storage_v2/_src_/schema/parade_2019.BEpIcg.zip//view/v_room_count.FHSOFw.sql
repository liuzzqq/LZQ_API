create definer = root@`%` view v_room_count as
select `parade_2019`.`bm_person_roomdiary`.`r_id` AS `r_id`, count(0) AS `pcount`
from `parade_2019`.`bm_person_roomdiary`
where ((`parade_2019`.`bm_person_roomdiary`.`status` = 0) and (`parade_2019`.`bm_person_roomdiary`.`type` = 1))
group by `parade_2019`.`bm_person_roomdiary`.`r_id`;

