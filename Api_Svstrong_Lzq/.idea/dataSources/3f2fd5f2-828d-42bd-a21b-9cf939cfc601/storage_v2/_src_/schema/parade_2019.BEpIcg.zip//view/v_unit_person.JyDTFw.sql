create definer = root@`%` view v_unit_person as
select 1                  AS `id`,
       `b`.`element`      AS `fenduiid`,
       `a`.`unit`         AS `danweiid`,
       `b`.`name`         AS `fangduiname`,
       `c`.`company_name` AS `danweiname`,
       count(0)           AS `count`
from ((`parade_2019`.`bm_person_info` `a` left join `parade_2019`.`bm_matrix_list` `b` on ((`a`.`element` = `b`.`element`)))
         left join `parade_2019`.`bm_person_unit` `c` on ((`c`.`code_number` = `a`.`unit`)))
group by `b`.`element`, `a`.`unit`, `b`.`name`, `c`.`company_name`;

