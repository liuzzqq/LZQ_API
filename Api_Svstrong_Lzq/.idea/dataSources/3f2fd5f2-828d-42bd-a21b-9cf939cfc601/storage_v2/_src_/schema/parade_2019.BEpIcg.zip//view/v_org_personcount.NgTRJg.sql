create definer = root@`%` view v_org_personcount as
select `parade_2019`.`bm_person_info`.`element` AS `element`, count(0) AS `p_count`
from `parade_2019`.`bm_person_info`
group by `parade_2019`.`bm_person_info`.`element`;

