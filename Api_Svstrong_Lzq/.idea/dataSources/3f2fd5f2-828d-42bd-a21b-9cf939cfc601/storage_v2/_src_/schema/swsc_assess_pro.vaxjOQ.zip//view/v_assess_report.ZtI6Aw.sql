create definer = root@`%` view v_assess_report as
select `mytable`.`evaluator_id`   AS `account`,
       sum(`mytable`.`zt_level1`) AS `zt_h_num`,
       sum(`mytable`.`zt_level2`) AS `zt_jh_num`,
       sum(`mytable`.`zt_level3`) AS `zt_yb_num`,
       sum(`mytable`.`zt_level4`) AS `zt_c_num`,
       sum(`mytable`.`level1`)    AS `h_num`,
       sum(`mytable`.`level2`)    AS `jh_num`,
       sum(`mytable`.`level3`)    AS `yb_num`,
       sum(`mytable`.`level4`)    AS `c_num`
from (select `swsc_assess_pro`.`sz_assess_result`.`evaluator_id`                   AS `evaluator_id`,
             sum(if((`swsc_assess_pro`.`sz_assess_result`.`result` = 1001), 1, 0)) AS `zt_level1`,
             sum(if((`swsc_assess_pro`.`sz_assess_result`.`result` = 1002), 1, 0)) AS `zt_level2`,
             sum(if((`swsc_assess_pro`.`sz_assess_result`.`result` = 1003), 1, 0)) AS `zt_level3`,
             sum(if((`swsc_assess_pro`.`sz_assess_result`.`result` = 1004), 1, 0)) AS `zt_level4`,
             0                                                                     AS `level1`,
             0                                                                     AS `level2`,
             0                                                                     AS `level3`,
             0                                                                     AS `level4`
      from `swsc_assess_pro`.`sz_assess_result`
      where (`swsc_assess_pro`.`sz_assess_result`.`evaluator_id` is not null)
      group by `swsc_assess_pro`.`sz_assess_result`.`evaluator_id`
      union all
      select `b`.`evaluator_id`                  AS `evaluator_id`,
             0                                   AS `zt_level1`,
             0                                   AS `zt_level2`,
             0                                   AS `zt_level3`,
             0                                   AS `zt_level4`,
             sum(if((`a`.`level` = 1001), 1, 0)) AS `level1`,
             sum(if((`a`.`level` = 1002), 1, 0)) AS `level2`,
             sum(if((`a`.`level` = 1003), 1, 0)) AS `level3`,
             sum(if((`a`.`level` = 1004), 1, 0)) AS `level4`
      from (`swsc_assess_pro`.`sz_assess_result_item` `a`
               left join `swsc_assess_pro`.`sz_assess_result` `b` on ((`a`.`result_id` = `b`.`id`)))
      group by `b`.`evaluator_id`) `mytable`
where (`mytable`.`evaluator_id` is not null)
group by `mytable`.`evaluator_id`;

